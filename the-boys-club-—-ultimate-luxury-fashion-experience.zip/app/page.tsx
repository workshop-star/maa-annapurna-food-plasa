'use client';

import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import { STORE_CONFIG, PRODUCTS, Product } from '@/lib/config';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { CollectionsSection } from '@/components/CollectionsSection';
import { EditorialSections } from '@/components/EditorialSections';
import { AboutSection } from '@/components/AboutSection';
import { StoreContact } from '@/components/StoreContact';
import { Footer } from '@/components/Footer';
import { ProductDetailModal } from '@/components/ProductDetailModal';
import { WishlistDrawer } from '@/components/WishlistDrawer';
import { CartDrawer, CartItem } from '@/components/CartDrawer';
import { SearchModal } from '@/components/SearchModal';
import { useIsMounted } from '@/hooks/use-mounted';

const CinematicIntro = dynamic(
  () => import('@/components/CinematicIntro').then((m) => m.CinematicIntro),
  { ssr: false }
);

const Showroom3D = dynamic(
  () => import('@/components/Showroom3D').then((m) => m.Showroom3D),
  {
    ssr: false,
    loading: () => (
      <div className="w-full bg-[#08080A] py-16 text-center">
        <div className="h-[520px] max-w-7xl mx-auto bg-[#0A0A0D] border border-neutral-800 rounded flex items-center justify-center">
          <span className="font-display text-xs tracking-widest text-[#D4AF37]">
            INITIALIZING 3D BOUTIQUE...
          </span>
        </div>
      </div>
    ),
  }
);

export default function HomePage() {
  const isMounted = useIsMounted();
  const [introFinished, setIntroFinished] = useState(false);
  const [forceReplayIntro, setForceReplayIntro] = useState(false);

  // Application State with lazy initializers from LocalStorage
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('tbc_wishlist');
        if (saved) return JSON.parse(saved);
      } catch {}
    }
    return [];
  });

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('tbc_cart');
        if (saved) return JSON.parse(saved);
      } catch {}
    }
    return [];
  });

  // Modals & Drawers State
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Save to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('tbc_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {}
  }, [wishlistIds]);

  useEffect(() => {
    try {
      localStorage.setItem('tbc_cart', JSON.stringify(cartItems));
    } catch (e) {}
  }, [cartItems]);

  // Wishlist Actions
  const handleToggleWishlist = (product: Product) => {
    setWishlistIds((prev) =>
      prev.includes(product.id)
        ? prev.filter((id) => id !== product.id)
        : [...prev, product.id]
    );
  };

  const handleRemoveFromWishlist = (productId: string) => {
    setWishlistIds((prev) => prev.filter((id) => id !== productId));
  };

  // Cart Actions
  const handleAddToBag = (
    product: Product,
    size?: string,
    color?: string,
    quantity: number = 1
  ) => {
    const chosenSize = size || product.sizes[0] || 'Standard';
    const chosenColor = color || product.colors[0]?.name || 'Standard';
    const uniqueItemId = `${product.id}-${chosenSize}-${chosenColor}`;

    setCartItems((prev) => {
      const existingIndex = prev.findIndex((item) => item.id === uniqueItemId);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        return [
          ...prev,
          {
            id: uniqueItemId,
            product,
            size: chosenSize,
            color: chosenColor,
            quantity,
          },
        ];
      }
    });

    // Auto open bag drawer for feedback
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (itemId: string, qty: number) => {
    setCartItems((prev) => {
      if (qty <= 0) {
        return prev.filter((item) => item.id !== itemId);
      }
      return prev.map((item) =>
        item.id === itemId ? { ...item, quantity: qty } : item
      );
    });
  };

  const handleRemoveCartItem = (itemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== itemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Navigation Scrolling Actions
  const scrollToCollection = () => {
    const el = document.getElementById('collection');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  // Wishlisted full products
  const activeWishlistIds = isMounted ? wishlistIds : [];
  const wishlistedProducts = PRODUCTS.filter((p) => activeWishlistIds.includes(p.id));

  const totalBagItemsCount = isMounted
    ? cartItems.reduce((sum, item) => sum + item.quantity, 0)
    : 0;

  return (
    <div className="min-h-screen bg-[#08080A] text-[#F4F4EE] selection:bg-[#D4AF37] selection:text-black">
      {/* Cinematic Intro Sequence (Client-only) */}
      <CinematicIntro
        forcePlay={forceReplayIntro}
        onComplete={() => {
          setIntroFinished(true);
          setForceReplayIntro(false);
        }}
      />

      {/* Floating Sticky Luxury Navbar */}
      <Navbar
        wishlistCount={activeWishlistIds.length}
        bagCount={totalBagItemsCount}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenBag={() => setIsCartOpen(true)}
        onReplayIntro={() => setForceReplayIntro(true)}
      />

      {/* Main Content Sections */}
      <main>
        {/* Full Screen Extreme Editorial Fashion Hero */}
        <Hero
          onExploreCollection={scrollToCollection}
          onDiscoverShowroom={() => scrollToSection('showroom')}
        />

        {/* Realistic 3D Boutique Showroom */}
        <Showroom3D onExploreCollection={scrollToCollection} />

        {/* Fashion Collections Grid & Working Filters */}
        <CollectionsSection
          onQuickView={(p) => setSelectedProduct(p)}
          onAddToBag={(p, size, color) => handleAddToBag(p, size, color, 1)}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={activeWishlistIds}
        />

        {/* Show-Stopping Editorial Sections A, B, C, D, E */}
        <EditorialSections
          onExploreCollection={() => scrollToCollection()}
          onQuickView={(p) => setSelectedProduct(p)}
          onOpenShowroom={() => scrollToSection('showroom')}
        />

        {/* About Brand Manifesto Section */}
        <AboutSection />

        {/* Flagship Store Contact & Direction Details */}
        <StoreContact />
      </main>

      {/* Footer */}
      <Footer onReplayIntro={() => setForceReplayIntro(true)} />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToBag={(p, size, color, qty) => {
          handleAddToBag(p, size, color, qty);
        }}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedProduct ? activeWishlistIds.includes(selectedProduct.id) : false}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      {/* Wishlist Sliding Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistItems={wishlistedProducts}
        onRemove={handleRemoveFromWishlist}
        onMoveToBag={(p) => handleAddToBag(p, p.sizes[0], p.colors[0]?.name, 1)}
      />

      {/* Shopping Bag Sliding Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={isMounted ? cartItems : []}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* Quick Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onSelectCategory={() => scrollToCollection()}
      />
    </div>
  );
}
