import type { Metadata } from 'next';
import './globals.css';
import { STORE_CONFIG } from '@/lib/config';

export const metadata: Metadata = {
  title: STORE_CONFIG.seo.title,
  description: STORE_CONFIG.seo.description,
  openGraph: {
    title: STORE_CONFIG.seo.title,
    description: STORE_CONFIG.seo.description,
    type: 'website',
    locale: 'en_IN',
    siteName: 'THE BOYS CLUB',
  },
  twitter: {
    card: 'summary_large_image',
    title: STORE_CONFIG.seo.title,
    description: STORE_CONFIG.seo.description,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ClothingStore',
    name: STORE_CONFIG.brand.name,
    description: STORE_CONFIG.seo.description,
    telephone: STORE_CONFIG.location.phone,
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'Angara, Cheldagsoso',
      addressLocality: 'Gondalipokhar',
      addressRegion: 'Jharkhand',
      postalCode: '835103',
      addressCountry: 'IN',
    },
    currenciesAccepted: 'INR',
    priceRange: '₹₹ - ₹₹₹',
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '5.0',
      reviewCount: '15',
    },
  };

  return (
    <html lang="en">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body suppressHydrationWarning className="bg-[#08080A] text-[#F4F4EE]">
        {children}
      </body>
    </html>
  );
}
