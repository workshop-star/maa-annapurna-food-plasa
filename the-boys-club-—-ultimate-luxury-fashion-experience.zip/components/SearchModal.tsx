'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, ArrowRight, CornerDownLeft } from 'lucide-react';
import { PRODUCTS, Product, STORE_CONFIG } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
  onSelectCategory: (categorySlug: string) => void;
}

export function SearchModal(props: SearchModalProps) {
  if (!props.isOpen) return null;

  return <SearchModalContent {...props} />;
}

function SearchModalContent({
  onClose,
  onSelectProduct,
  onSelectCategory,
}: SearchModalProps) {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = setTimeout(() => inputRef.current?.focus(), 80);
    return () => clearTimeout(t);
  }, []);

  // Keyboard shortcut ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const results = query.trim()
    ? PRODUCTS.filter((item) => {
        const q = query.toLowerCase();
        return (
          item.name.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q) ||
          item.description.toLowerCase().includes(q) ||
          item.colors.some((c) => c.name.toLowerCase().includes(q))
        );
      })
    : [];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 md:pt-24 px-4 bg-black/85 backdrop-blur-md">
        <div className="fixed inset-0" onClick={onClose} />

        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.98 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-2xl bg-[#0F0F14] border border-[#27272A] rounded-sm overflow-hidden shadow-2xl z-10 flex flex-col max-h-[80vh]"
        >
          {/* Search Input Bar */}
          <div className="p-4 border-b border-neutral-800 flex items-center gap-3 bg-[#0C0C10]">
            <Search className="w-5 h-5 text-[#D4AF37] shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search garments, oversized tees, raw denim, jackets..."
              className="w-full bg-transparent text-white text-sm placeholder-neutral-500 focus:outline-none"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="text-neutral-500 hover:text-white p-1"
                aria-label="Clear query"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="text-xs uppercase tracking-wider text-neutral-400 hover:text-white px-2 py-1 border border-neutral-800 rounded shrink-0"
            >
              ESC
            </button>
          </div>

          {/* Quick Category Tags when no query */}
          {!query.trim() && (
            <div className="p-6 space-y-4">
              <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold block">
                Popular Searches & Categories
              </span>
              <div className="flex flex-wrap gap-2">
                {STORE_CONFIG.categories.slice(1, 8).map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      onSelectCategory(cat.slug);
                      onClose();
                    }}
                    className="px-3 py-1.5 bg-neutral-900 border border-neutral-800 hover:border-[#D4AF37] hover:text-[#D4AF37] text-neutral-300 text-xs rounded-sm transition-colors"
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Search Results */}
          {query.trim() && (
            <div className="overflow-y-auto p-4 flex-grow space-y-2">
              <div className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold px-2 pb-2">
                {results.length} Pieces Found for &ldquo;{query}&rdquo;
              </div>

              {results.length === 0 ? (
                <div className="py-12 text-center space-y-2">
                  <p className="text-sm font-bold text-white">No items found</p>
                  <p className="text-xs text-neutral-400">
                    Try searching for &quot;Oversized&quot;, &quot;Bomber&quot;, &quot;Selvedge&quot;, or &quot;Shirt&quot;.
                  </p>
                </div>
              ) : (
                results.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => {
                      onSelectProduct(product);
                      onClose();
                    }}
                    className="p-2.5 rounded hover:bg-neutral-900/80 border border-transparent hover:border-neutral-800 transition-colors cursor-pointer flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative w-12 h-14 rounded overflow-hidden bg-neutral-900 shrink-0">
                        <FashionImage src={product.image} alt={product.name} fill />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">
                          {product.category.replace('-', ' ')}
                        </span>
                        <h4 className="font-display text-sm font-bold text-white group-hover:text-[#D4AF37] transition-colors">
                          {product.name}
                        </h4>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs font-bold text-[#D4AF37] tabular-nums">
                        {STORE_CONFIG.currency.format(product.price)}
                      </span>
                      <CornerDownLeft className="w-3.5 h-3.5 text-neutral-600 group-hover:text-[#D4AF37] transition-colors" />
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
