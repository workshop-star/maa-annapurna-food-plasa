'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { STORE_CONFIG } from '@/lib/config';

interface CinematicIntroProps {
  onComplete: () => void;
  forcePlay?: boolean;
}

export function CinematicIntro({ onComplete, forcePlay = false }: CinematicIntroProps) {
  const [stage, setStage] = useState<1 | 2 | 3 | 4>(1);
  const [isVisible, setIsVisible] = useState(() => {
    if (typeof window !== 'undefined') {
      if (!forcePlay && sessionStorage.getItem('tbc_cinematic_intro_seen') === 'true') {
        return false;
      }
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return false;
      }
    }
    return true;
  });

  const handleSkip = React.useCallback(() => {
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('tbc_cinematic_intro_seen', 'true');
    }
    setIsVisible(false);
    onComplete();
  }, [onComplete]);

  const handleComplete = React.useCallback(() => {
    if (typeof window !== 'undefined') {
      sessionStorage.setItem('tbc_cinematic_intro_seen', 'true');
    }
    setIsVisible(false);
    onComplete();
  }, [onComplete]);

  useEffect(() => {
    if (!isVisible) {
      onComplete();
    }
  }, [isVisible, onComplete]);

  useEffect(() => {
    if (!isVisible) return;

    const t1 = setTimeout(() => setStage(2), 1500);
    const t2 = setTimeout(() => setStage(3), 3000);
    const t3 = setTimeout(() => setStage(4), 4400);
    const t4 = setTimeout(() => {
      handleComplete();
    }, 5400);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [isVisible, handleSkip, handleComplete]);

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="fixed inset-0 z-50 overflow-hidden bg-[#050507] flex items-center justify-center select-none"
      >
        {/* Skip Button */}
        <button
          onClick={handleSkip}
          aria-label="Skip introductory animation"
          className="absolute top-8 right-8 z-50 text-[11px] uppercase tracking-[0.25em] text-[#D4AF37]/80 hover:text-[#FFF3D6] border border-[#D4AF37]/30 hover:border-[#D4AF37] px-4 py-2 bg-black/60 backdrop-blur-sm transition-all duration-300 rounded-sm"
        >
          Skip Intro [ESC]
        </button>

        {/* Ambient Atmospheric Lighting */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[radial-gradient(circle,rgba(212,175,55,0.12)_0%,transparent_70%)] blur-2xl" />
          <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-black to-transparent opacity-80" />
          <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-black to-transparent opacity-80" />
        </div>

        {/* Scene 1 & 2: Monogram & Brand reveal */}
        {(stage === 1 || stage === 2) && (
          <div className="relative z-20 flex flex-col items-center justify-center text-center px-4">
            {/* Metallic Monogram */}
            <motion.div
              initial={{ scale: 0.85, opacity: 0, filter: 'blur(10px)' }}
              animate={{ scale: 1, opacity: 1, filter: 'blur(0px)' }}
              transition={{ duration: 1.2, ease: 'easeOut' }}
              className="relative mb-6"
            >
              <div className="w-28 h-28 md:w-36 md:h-36 relative flex items-center justify-center">
                {/* Metallic Ring with Gold Sheen */}
                <svg
                  viewBox="0 0 100 100"
                  className="w-full h-full drop-shadow-[0_0_25px_rgba(212,175,55,0.35)]"
                >
                  <circle
                    cx="50"
                    cy="50"
                    r="46"
                    fill="none"
                    stroke="#27272A"
                    strokeWidth="1.5"
                  />
                  <motion.circle
                    cx="50"
                    cy="50"
                    r="46"
                    fill="none"
                    stroke="url(#goldGradientIntro)"
                    strokeWidth="2"
                    strokeDasharray="290"
                    initial={{ strokeDashoffset: 290 }}
                    animate={{ strokeDashoffset: 0 }}
                    transition={{ duration: 2, ease: 'easeInOut' }}
                  />
                  <defs>
                    <linearGradient
                      id="goldGradientIntro"
                      x1="0%"
                      y1="0%"
                      x2="100%"
                      y2="100%"
                    >
                      <stop offset="0%" stopColor="#FFF2D1" />
                      <stop offset="50%" stopColor="#D4AF37" />
                      <stop offset="100%" stopColor="#8A6B1A" />
                    </linearGradient>
                  </defs>
                </svg>

                {/* TBC Monogram Core */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-display text-4xl md:text-5xl font-extrabold tracking-[0.2em] gold-gradient-text pl-1.5">
                    {STORE_CONFIG.brand.monogram}
                  </span>
                </div>
              </div>
            </motion.div>

            {/* Scene 2 Typography Reveal */}
            {stage >= 2 && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="space-y-3"
              >
                <div className="overflow-hidden">
                  <motion.h1
                    initial={{ y: 30 }}
                    animate={{ y: 0 }}
                    transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
                    className="font-display text-2xl md:text-4xl lg:text-5xl tracking-[0.3em] font-black text-white"
                  >
                    {STORE_CONFIG.brand.name}
                  </motion.h1>
                </div>

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                  className="flex items-center justify-center gap-3 text-xs md:text-sm tracking-[0.35em] text-[#D4AF37] font-medium uppercase"
                >
                  <span>GONDALIPOKHAR</span>
                  <span className="text-neutral-600">·</span>
                  <span>{STORE_CONFIG.brand.tagline}</span>
                </motion.div>
              </motion.div>
            )}
          </div>
        )}

        {/* Scene 3 & 4: Architectural Showroom Doors Opening */}
        {(stage === 3 || stage === 4) && (
          <div className="absolute inset-0 z-30 perspective-[1200px] overflow-hidden flex">
            {/* Left Showroom Architectural Door */}
            <motion.div
              initial={{ x: '0%', rotateY: 0 }}
              animate={{ x: '-102%', rotateY: -22 }}
              transition={{ duration: 1.4, ease: [0.25, 1, 0.5, 1] }}
              className="w-1/2 h-full bg-[#0D0D10] border-r border-[#D4AF37]/40 relative origin-left shadow-[25px_0_50px_rgba(0,0,0,0.9)] flex items-center justify-end pr-8 md:pr-14"
            >
              {/* Door Paneling Texture */}
              <div className="absolute inset-4 border border-[#27272A]/80 pointer-events-none" />
              <div className="absolute inset-10 border border-[#D4AF37]/20 pointer-events-none" />
              {/* Brass Door Handle */}
              <div className="w-2 md:w-3 h-48 md:h-64 bg-gradient-to-b from-[#FFF0C2] via-[#D4AF37] to-[#7A5C14] rounded-sm shadow-2xl relative z-10" />
            </motion.div>

            {/* Right Showroom Architectural Door */}
            <motion.div
              initial={{ x: '0%', rotateY: 0 }}
              animate={{ x: '102%', rotateY: 22 }}
              transition={{ duration: 1.4, ease: [0.25, 1, 0.5, 1] }}
              className="w-1/2 h-full bg-[#0D0D10] border-l border-[#D4AF37]/40 relative origin-right shadow-[-25px_0_50px_rgba(0,0,0,0.9)] flex items-center justify-start pl-8 md:pl-14"
            >
              <div className="absolute inset-4 border border-[#27272A]/80 pointer-events-none" />
              <div className="absolute inset-10 border border-[#D4AF37]/20 pointer-events-none" />
              {/* Brass Door Handle */}
              <div className="w-2 md:w-3 h-48 md:h-64 bg-gradient-to-b from-[#FFF0C2] via-[#D4AF37] to-[#7A5C14] rounded-sm shadow-2xl relative z-10" />
            </motion.div>

            {/* Behind the doors: High-end Boutique Reveal Scene */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: stage === 4 ? 1.05 : 1, opacity: 1 }}
              transition={{ duration: 1.5, ease: 'easeOut' }}
              className="absolute inset-0 -z-10 flex flex-col items-center justify-center bg-radial from-[#1A1A22] via-[#0E0E12] to-[#050507]"
            >
              <div className="relative text-center px-4 space-y-4 max-w-xl">
                <span className="text-[11px] tracking-[0.4em] uppercase text-[#D4AF37] block">
                  ENTERING THE FLAGSHIP
                </span>
                <h2 className="font-display text-3xl md:text-5xl font-black text-white tracking-[0.2em] leading-tight">
                  THE BOYS CLUB
                </h2>
                <p className="text-sm md:text-base text-neutral-300 font-light tracking-wider">
                  &ldquo;{STORE_CONFIG.brand.tagline}&rdquo;
                </p>
                <div className="pt-4 flex items-center justify-center gap-2">
                  <div className="w-12 h-px bg-[#D4AF37]" />
                  <span className="text-[10px] tracking-widest text-neutral-400 uppercase">
                    SHOWROOM UNLOCKED
                  </span>
                  <div className="w-12 h-px bg-[#D4AF37]" />
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
