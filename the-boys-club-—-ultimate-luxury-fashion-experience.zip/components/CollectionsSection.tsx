'use client';

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Eye, ShoppingBag, SlidersHorizontal, Check, RefreshCw, X } from 'lucide-react';
import { STORE_CONFIG, PRODUCTS, Product, Category } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

interface CollectionsProps {
  onQuickView: (product: Product) => void;
  onAddToBag: (product: Product, size?: string, color?: string) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: string[];
}

export function CollectionsSection({
  onQuickView,
  onAddToBag,
  onToggleWishlist,
  wishlistIds,
}: CollectionsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('all');
  const [onlyInStock, setOnlyInStock] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'newest'>('featured');
  const [hoveredProduct, setHoveredProduct] = useState<string | null>(null);
  const [showFiltersDrawer, setShowFiltersDrawer] = useState<boolean>(false);

  // Available filter options
  const allSizes = ['all', 'S', 'M', 'L', 'XL', 'XXL', '30', '32', '34', '36', '38', '40', '42'];

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((item) => {
      // Category filter
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'new-arrivals') {
          if (!item.isNewArrival) return false;
        } else if (selectedCategory === 'streetwear') {
          if (!item.isStreetwear && item.category !== 'streetwear') return false;
        } else if (item.category !== selectedCategory) {
          return false;
        }
      }

      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        const matchesCat = item.category.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc && !matchesCat) return false;
      }

      // Size filter
      if (selectedSize !== 'all') {
        if (!item.sizes.includes(selectedSize)) return false;
      }

      // Stock status filter
      if (onlyInStock && item.stockStatus !== 'in_stock') {
        return false;
      }

      // Price range filter
      if (selectedPriceRange === 'under-2500' && item.price >= 2500) return false;
      if (selectedPriceRange === '2500-4000' && (item.price < 2500 || item.price > 4000)) return false;
      if (selectedPriceRange === 'above-4000' && item.price <= 4000) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'newest') return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
      return 0; // featured default
    });
  }, [selectedCategory, searchQuery, selectedSize, onlyInStock, selectedPriceRange, sortBy]);

  const handleResetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setSelectedSize('all');
    setSelectedPriceRange('all');
    setOnlyInStock(false);
    setSortBy('featured');
  };

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    searchQuery.trim() !== '' ||
    selectedSize !== 'all' ||
    selectedPriceRange !== 'all' ||
    onlyInStock;

  return (
    <section id="collection" className="relative w-full bg-[#08080A] py-20 px-4 sm:px-6 lg:px-8 border-t border-neutral-900">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="text-xs uppercase tracking-[0.35em] text-[#D4AF37] font-semibold block mb-2">
              CURATED MENSWEAR
            </span>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
              THE COLLECTIONS
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 mt-2 max-w-xl font-light">
              Architectural cuts, premium cotton fabrics, selvedge denim and contemporary festive couture tailored for everyday distinction.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Filter Toggle Mobile/Desktop */}
            <button
              onClick={() => setShowFiltersDrawer(!showFiltersDrawer)}
              className={`px-4 py-2.5 text-xs uppercase tracking-wider font-semibold rounded-sm border flex items-center gap-2 transition-colors ${
                hasActiveFilters
                  ? 'border-[#D4AF37] text-[#D4AF37] bg-[#D4AF37]/10'
                  : 'border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters {hasActiveFilters ? '(Active)' : ''}</span>
            </button>

            {/* Sorting Select */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#121216] border border-neutral-800 text-neutral-300 text-xs uppercase tracking-wider rounded-sm px-3 py-2.5 focus:border-[#D4AF37] focus:outline-none cursor-pointer"
            >
              <option value="featured">Sort: Featured</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="newest">Newest Arrivals</option>
            </select>
          </div>
        </div>

        {/* Categories Tab Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 scrollbar-none mb-8">
          {STORE_CONFIG.categories.map((cat) => {
            const isActive = selectedCategory === cat.slug;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.slug)}
                className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider rounded-sm whitespace-nowrap transition-all duration-200 border ${
                  isActive
                    ? 'bg-[#D4AF37] text-black border-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.25)]'
                    : 'bg-[#101014] text-neutral-400 hover:text-white border-neutral-800/80 hover:border-neutral-700'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>

        {/* Collapsible Filter Bar */}
        {showFiltersDrawer && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-[#101014] border border-neutral-800 rounded-sm p-5 mb-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {/* Search Input */}
            <div>
              <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-2 font-medium">
                Search Catalog
              </label>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="e.g. Bomber, Selvedge, Black..."
                className="w-full bg-[#18181F] border border-neutral-700 text-white text-xs px-3 py-2 rounded-sm focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            {/* Size Filter */}
            <div>
              <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-2 font-medium">
                Size
              </label>
              <select
                value={selectedSize}
                onChange={(e) => setSelectedSize(e.target.value)}
                className="w-full bg-[#18181F] border border-neutral-700 text-neutral-200 text-xs px-3 py-2 rounded-sm focus:border-[#D4AF37] focus:outline-none"
              >
                <option value="all">All Sizes</option>
                {allSizes.slice(1).map((size) => (
                  <option key={size} value={size}>
                    Size {size}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Filter */}
            <div>
              <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-2 font-medium">
                Price Range
              </label>
              <select
                value={selectedPriceRange}
                onChange={(e) => setSelectedPriceRange(e.target.value)}
                className="w-full bg-[#18181F] border border-neutral-700 text-neutral-200 text-xs px-3 py-2 rounded-sm focus:border-[#D4AF37] focus:outline-none"
              >
                <option value="all">All Prices</option>
                <option value="under-2500">Under ₹2,500</option>
                <option value="2500-4000">₹2,500 – ₹4,000</option>
                <option value="above-4000">Above ₹4,000</option>
              </select>
            </div>

            {/* In-Stock Toggle & Reset */}
            <div className="flex flex-col justify-between">
              <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-2 font-medium">
                Stock Availability
              </label>
              <div className="flex items-center gap-2 mt-1">
                <input
                  type="checkbox"
                  id="stockToggle"
                  checked={onlyInStock}
                  onChange={(e) => setOnlyInStock(e.target.checked)}
                  className="rounded accent-[#D4AF37] cursor-pointer w-4 h-4"
                />
                <label htmlFor="stockToggle" className="text-xs text-neutral-300 cursor-pointer">
                  In Stock Only
                </label>
              </div>

              {hasActiveFilters && (
                <button
                  onClick={handleResetFilters}
                  className="mt-3 text-[11px] uppercase tracking-wider text-[#D4AF37] hover:underline flex items-center gap-1.5 self-start"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Reset All Filters</span>
                </button>
              )}
            </div>
          </motion.div>
        )}

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center border border-dashed border-neutral-800 rounded-sm p-8 bg-[#0D0D10]">
            <span className="font-display text-xl text-white font-bold block mb-2">
              No Pieces Match Your Current Selection
            </span>
            <p className="text-xs text-neutral-400 max-w-md mx-auto mb-6">
              Try adjusting your category, size, or price filters to discover the current collection.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-5 py-2.5 text-xs uppercase tracking-widest font-bold bg-[#D4AF37] text-black rounded-sm"
            >
              Clear All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredProducts.map((product) => {
              const isWishlisted = wishlistIds.includes(product.id);
              const isHovered = hoveredProduct === product.id;

              return (
                <motion.div
                  key={product.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  onMouseEnter={() => setHoveredProduct(product.id)}
                  onMouseLeave={() => setHoveredProduct(null)}
                  className="group relative bg-[#0E0E12] border border-neutral-800/80 rounded-sm overflow-hidden flex flex-col justify-between hover:border-neutral-700 transition-all duration-300 shadow-lg hover:shadow-2xl"
                >
                  {/* Top Image Showcase */}
                  <div className="relative aspect-[3/4] w-full overflow-hidden bg-neutral-900 cursor-pointer" onClick={() => onQuickView(product)}>
                    {/* Primary Image */}
                    <div className={`absolute inset-0 transition-opacity duration-700 ${isHovered && product.secondaryImage ? 'opacity-0' : 'opacity-100'}`}>
                      <FashionImage
                        src={product.image}
                        alt={product.name}
                        fill
                        className="group-hover:scale-105 transition-transform duration-700 ease-out"
                      />
                    </div>

                    {/* Secondary Image on Hover */}
                    {product.secondaryImage && (
                      <div className={`absolute inset-0 transition-opacity duration-700 ${isHovered ? 'opacity-100 scale-105' : 'opacity-0 scale-100'}`}>
                        <FashionImage
                          src={product.secondaryImage}
                          alt={`${product.name} alternate view`}
                          fill
                          className="transition-transform duration-700 ease-out"
                        />
                      </div>
                    )}

                    {/* Dark gradient scrim */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

                    {/* Editorial Tag */}
                    {product.tag && (
                      <div className="absolute top-3 left-3 z-10 px-2.5 py-1 bg-black/80 backdrop-blur-sm border border-neutral-800 text-[10px] uppercase tracking-[0.2em] text-[#D4AF37] font-bold">
                        {product.tag}
                      </div>
                    )}

                    {/* Wishlist Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleWishlist(product);
                      }}
                      aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                      className={`absolute top-3 right-3 z-10 p-2.5 rounded-sm backdrop-blur-md transition-all duration-300 ${
                        isWishlisted
                          ? 'bg-[#D4AF37] text-black shadow-[0_0_15px_rgba(212,175,55,0.5)]'
                          : 'bg-black/60 text-white hover:text-[#D4AF37] hover:bg-black/80'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-black' : ''}`} />
                    </button>

                    {/* Hover Quick Actions Overlay Bar */}
                    <div className="absolute bottom-3 inset-x-3 z-10 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onQuickView(product);
                        }}
                        className="flex-1 py-2.5 bg-black/85 hover:bg-black text-white hover:text-[#D4AF37] border border-neutral-700 text-[11px] font-bold uppercase tracking-widest rounded-sm transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Quick View</span>
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onAddToBag(product, product.sizes[0], product.colors[0]?.name);
                        }}
                        className="py-2.5 px-3 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black text-[11px] font-bold uppercase tracking-wider rounded-sm transition-colors flex items-center justify-center"
                        title="Add to Bag"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Card Content & Metadata */}
                  <div className="p-4 sm:p-5 flex flex-col justify-between flex-grow">
                    <div>
                      {/* Quiet Unboxed Metadata: Category & Stock Status */}
                      <div className="flex items-center justify-between text-[11px] tracking-wider text-neutral-400 uppercase mb-1.5">
                        <span>{product.category.replace('-', ' ')}</span>
                        {product.stockStatus === 'low_stock' && (
                          <span className="text-amber-400 font-semibold">Only 3 Left</span>
                        )}
                        {product.stockStatus === 'in_stock' && (
                          <span className="text-neutral-500">In Stock</span>
                        )}
                      </div>

                      {/* Product Name */}
                      <h3
                        onClick={() => onQuickView(product)}
                        className="font-display text-base font-bold text-white tracking-wide hover:text-[#D4AF37] transition-colors cursor-pointer line-clamp-1"
                      >
                        {product.name}
                      </h3>

                      {/* Sizes indicator */}
                      <div className="flex items-center gap-1.5 mt-2">
                        <span className="text-[10px] text-neutral-500 uppercase tracking-wider">Sizes:</span>
                        <div className="flex items-center gap-1 text-[10px] font-mono text-neutral-300">
                          {product.sizes.map((s) => (
                            <span key={s} className="px-1 py-0.5 bg-neutral-900 border border-neutral-800 rounded">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Price and Color Swatches Row */}
                    <div className="mt-4 pt-3 border-t border-neutral-850 flex items-center justify-between">
                      {/* Price in Tabular Numerals */}
                      <div className="flex items-baseline gap-2">
                        <span className="font-mono text-base font-bold text-white tabular-nums">
                          {STORE_CONFIG.currency.format(product.price)}
                        </span>
                        {product.originalPrice && (
                          <span className="font-mono text-xs text-neutral-500 line-through tabular-nums">
                            {STORE_CONFIG.currency.format(product.originalPrice)}
                          </span>
                        )}
                      </div>

                      {/* Color Palette Swatches */}
                      <div className="flex items-center gap-1">
                        {product.colors.map((c) => (
                          <span
                            key={c.name}
                            className="w-3.5 h-3.5 rounded-full border border-neutral-700 block shadow-inner"
                            style={{ backgroundColor: c.hex }}
                            title={c.name}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
