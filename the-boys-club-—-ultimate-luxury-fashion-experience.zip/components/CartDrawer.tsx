'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, MessageSquare, CheckCircle, Info } from 'lucide-react';
import { Product, STORE_CONFIG } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

export interface CartItem {
  id: string; // unique item id (productId + size + color)
  product: Product;
  size: string;
  color: string;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, qty: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [orderSent, setOrderSent] = useState(false);

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const totalItemsCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) return;

    // Simulate demo order confirmation with clear disclosure
    setOrderSent(true);
  };

  const handleWhatsAppEnquiry = () => {
    const itemsSummary = cartItems
      .map(
        (i) =>
          `• ${i.product.name} (Size: ${i.size}, Color: ${i.color}) x${i.quantity} = ₹${i.product.price * i.quantity}`
      )
      .join('%0A');

    const message = `Hello THE BOYS CLUB Gondalipokhar, I would like to enquire about ordering the following pieces from your online catalogue:%0A%0A${itemsSummary}%0A%0ATotal Amount: ₹${subtotal}%0A%0APlease let me know availability for in-store pickup or delivery.`;

    window.open(`https://wa.me/919031752523?text=${message}`, '_blank');
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Sliding Bag Panel */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-md bg-[#0D0D11] border-l border-neutral-800 shadow-2xl flex flex-col justify-between z-10 h-full"
        >
          {/* Header */}
          <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-[#0A0A0D]">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#D4AF37]" />
              <h2 className="font-display text-base font-bold text-white tracking-widest uppercase">
                SHOPPING BAG ({totalItemsCount})
              </h2>
            </div>
            <button
              onClick={onClose}
              aria-label="Close shopping bag"
              className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-grow overflow-y-auto p-5 space-y-4">
            {orderSent ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37] flex items-center justify-center mx-auto text-[#D4AF37]">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h3 className="font-display text-xl font-bold text-white">
                  Boutique Enquiry Received!
                </h3>
                <p className="text-xs text-neutral-300 max-w-sm mx-auto leading-relaxed">
                  Thank you, <span className="font-semibold text-white">{customerName}</span>. Your enquiry for {totalItemsCount} pieces totaling{' '}
                  <span className="font-mono text-[#D4AF37]">{STORE_CONFIG.currency.format(subtotal)}</span> has been recorded for THE BOYS CLUB flagship store at Gondalipokhar.
                </p>
                <div className="p-3 bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-400 rounded text-left space-y-1">
                  <div className="font-bold text-neutral-300 uppercase">Demo Store Notice:</div>
                  <p>
                    Live backend payments and inventory syncing require production gateway credentials. To confirm this order right now, tap below to contact the boutique directly via WhatsApp or call 09031752523.
                  </p>
                </div>
                <div className="pt-2 flex flex-col gap-2">
                  <button
                    onClick={handleWhatsAppEnquiry}
                    className="w-full py-3 bg-[#25D366] hover:bg-[#20b858] text-black font-bold text-xs uppercase tracking-wider rounded-sm flex items-center justify-center gap-2"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Send Order on WhatsApp</span>
                  </button>
                  <button
                    onClick={() => {
                      onClearCart();
                      setOrderSent(false);
                      onClose();
                    }}
                    className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs uppercase tracking-wider rounded-sm"
                  >
                    Continue Shopping
                  </button>
                </div>
              </div>
            ) : isCheckingOut ? (
              /* Demo Checkout / Enquiry Form */
              <form onSubmit={handleCheckoutSubmit} className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                  <span className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold">
                    Customer Details
                  </span>
                  <button
                    type="button"
                    onClick={() => setIsCheckingOut(false)}
                    className="text-[11px] text-neutral-400 hover:text-white underline"
                  >
                    Back to Items
                  </button>
                </div>

                <div>
                  <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1.5 font-medium">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full bg-[#18181F] border border-neutral-700 text-white text-xs px-3 py-2.5 rounded-sm focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1.5 font-medium">
                    Phone Number (for Order Confirmation) *
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 09031752523"
                    className="w-full bg-[#18181F] border border-neutral-700 text-white text-xs px-3 py-2.5 rounded-sm focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1.5 font-medium">
                    Delivery Address / Store Pickup Note
                  </label>
                  <textarea
                    rows={3}
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="Enter delivery destination or specify in-store pickup at Gondalipokhar"
                    className="w-full bg-[#18181F] border border-neutral-700 text-white text-xs px-3 py-2 rounded-sm focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                {/* Subtotal Summary */}
                <div className="p-3 bg-neutral-900 border border-neutral-800 rounded text-xs space-y-1.5">
                  <div className="flex justify-between text-neutral-400">
                    <span>Order Subtotal</span>
                    <span className="font-mono text-white tabular-nums">
                      {STORE_CONFIG.currency.format(subtotal)}
                    </span>
                  </div>
                  <div className="flex justify-between text-neutral-400">
                    <span>Delivery</span>
                    <span className="text-emerald-400">Complimentary (Flagship)</span>
                  </div>
                  <div className="pt-2 border-t border-neutral-800 flex justify-between font-bold text-white text-sm">
                    <span>Estimated Total</span>
                    <span className="font-mono text-[#D4AF37] tabular-nums">
                      {STORE_CONFIG.currency.format(subtotal)}
                    </span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-all shadow-[0_0_15px_rgba(212,175,55,0.25)]"
                >
                  PLACE STORE ENQUIRY
                </button>
              </form>
            ) : cartItems.length === 0 ? (
              <div className="py-20 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center mx-auto text-neutral-500">
                  <ShoppingBag className="w-7 h-7" />
                </div>
                <h3 className="font-display text-base font-bold text-white">Your Bag is Empty</h3>
                <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                  Explore our luxury streetwear drops, oversized t-shirts, and tailored jackets to build your look.
                </p>
                <button
                  onClick={onClose}
                  className="mt-2 px-5 py-2.5 text-xs font-bold uppercase tracking-wider bg-[#D4AF37] text-black rounded-sm"
                >
                  START SHOPPING
                </button>
              </div>
            ) : (
              /* Item List */
              cartItems.map((item) => (
                <div
                  key={item.id}
                  className="p-3 bg-[#131318] border border-neutral-800 rounded-sm flex gap-3 group"
                >
                  {/* Thumbnail */}
                  <div className="relative w-20 h-24 rounded overflow-hidden shrink-0 bg-neutral-900">
                    <FashionImage src={item.product.image} alt={item.product.name} fill />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="font-display text-xs font-bold text-white truncate">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-neutral-500 hover:text-red-400 p-1"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 text-[10px] uppercase text-neutral-400 mt-1">
                        <span>Size: <strong className="text-white">{item.size}</strong></span>
                        <span>·</span>
                        <span>Colour: <strong className="text-white">{item.color}</strong></span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-neutral-850">
                      <div className="flex items-center border border-neutral-700 rounded bg-neutral-900">
                        <button
                          onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                          className="px-2 py-0.5 text-neutral-400 hover:text-white text-xs"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-mono font-bold text-white tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                          className="px-2 py-0.5 text-neutral-400 hover:text-white text-xs"
                        >
                          +
                        </button>
                      </div>

                      <span className="font-mono text-xs font-bold text-[#D4AF37] tabular-nums">
                        {STORE_CONFIG.currency.format(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer with Calculations & Checkout Button */}
          {cartItems.length > 0 && !orderSent && !isCheckingOut && (
            <div className="p-5 border-t border-neutral-800 bg-[#0A0A0D] space-y-4">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-neutral-400">
                  <span>Subtotal</span>
                  <span className="font-mono text-white tabular-nums font-semibold">
                    {STORE_CONFIG.currency.format(subtotal)}
                  </span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>Standard Shipping</span>
                  <span className="text-emerald-400">Included</span>
                </div>
              </div>

              <div className="pt-2 border-t border-neutral-850 flex justify-between items-baseline">
                <span className="font-display text-sm font-bold text-white uppercase tracking-wider">
                  Total
                </span>
                <span className="font-mono text-lg font-bold text-[#D4AF37] tabular-nums">
                  {STORE_CONFIG.currency.format(subtotal)}
                </span>
              </div>

              <div className="space-y-2 pt-1">
                <button
                  onClick={() => setIsCheckingOut(true)}
                  className="w-full py-3.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-all duration-300 flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(212,175,55,0.25)]"
                >
                  <span>PROCEED TO ENQUIRY / CHECKOUT</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={handleWhatsAppEnquiry}
                  className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-850 border border-neutral-700 text-neutral-300 hover:text-white text-xs font-semibold uppercase tracking-wider rounded-sm flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-[#25D366]" />
                  <span>Enquire on WhatsApp Directly</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" />
                <span>Client demo mode · No payment taken without confirmation</span>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
