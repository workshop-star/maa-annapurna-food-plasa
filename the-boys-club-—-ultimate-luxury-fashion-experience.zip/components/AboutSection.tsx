'use client';

import React from 'react';
import { motion } from 'motion/react';
import { STORE_CONFIG } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

export function AboutSection() {
  return (
    <section id="about" className="relative w-full bg-[#08080A] py-24 border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Editorial Visual (5 Cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative aspect-[4/5] rounded-sm overflow-hidden border border-[#27272A] shadow-2xl group">
              <FashionImage
                src="https://images.unsplash.com/photo-1603252109303-2751441dd157?q=80&w=1200&auto=format&fit=crop"
                alt="THE BOYS CLUB Lifestyle Philosophy"
                fill
                className="group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="font-display text-xs tracking-widest text-[#D4AF37] uppercase block mb-1">
                  OUR PHILOSOPHY
                </span>
                <p className="text-white font-medium text-sm">
                  Confidence tailored into every seam.
                </p>
              </div>
            </div>
            {/* Ambient metallic corner accent */}
            <div className="absolute -top-3 -left-3 w-16 h-16 border-t-2 border-l-2 border-[#D4AF37]/40 pointer-events-none" />
          </div>

          {/* Right Brand Prose (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <span className="text-xs uppercase tracking-[0.35em] text-[#D4AF37] font-semibold block">
                MANIFESTO
              </span>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                {STORE_CONFIG.brand.aboutHeadline}
              </h2>
            </div>

            <p className="text-base sm:text-lg text-neutral-300 font-light leading-relaxed">
              {STORE_CONFIG.brand.aboutCopy}
            </p>

            <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-6 border-t border-neutral-850">
              <div>
                <span className="font-display text-sm font-bold text-white block mb-1">
                  ARCHITECTURAL VOLUME
                </span>
                <p className="text-xs text-neutral-400 font-light leading-normal">
                  Drop-shoulders, wide leg breaks, and structured collars tailored to project quiet strength.
                </p>
              </div>
              <div>
                <span className="font-display text-sm font-bold text-white block mb-1">
                  TACTILE LUXURY
                </span>
                <p className="text-xs text-neutral-400 font-light leading-normal">
                  Dense 280-450 GSM pure cotton knits, virgin selvedge yarns, and mother-of-pearl hardware.
                </p>
              </div>
            </div>

            <div className="pt-4 flex items-center gap-4 text-xs text-neutral-400">
              <span className="font-display text-white font-bold tracking-widest uppercase">
                {STORE_CONFIG.brand.name}
              </span>
              <span>·</span>
              <span>Contemporary Clothing Store Demonstration</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
