'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Heart, ShoppingBag, Check, ShieldCheck, Truck, RefreshCw, AlertCircle } from 'lucide-react';
import { Product, STORE_CONFIG, PRODUCTS } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToBag: (product: Product, size: string, color: string, quantity: number) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  onSelectProduct: (product: Product) => void;
}

export function ProductDetailModal({
  product,
  onClose,
  onAddToBag,
  onToggleWishlist,
  isWishlisted,
  onSelectProduct,
}: ProductDetailModalProps) {
  // Handle ESC key to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!product) return null;

  return (
    <ProductDetailModalContent
      key={product.id}
      product={product}
      onClose={onClose}
      onAddToBag={onAddToBag}
      onToggleWishlist={onToggleWishlist}
      isWishlisted={isWishlisted}
      onSelectProduct={onSelectProduct}
    />
  );
}

function ProductDetailModalContent({
  product,
  onClose,
  onAddToBag,
  onToggleWishlist,
  isWishlisted,
  onSelectProduct,
}: ProductDetailModalProps & { product: Product }) {
  const [selectedImage, setSelectedImage] = useState<string>(product.image);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || '');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0]?.name || '');
  const [quantity, setQuantity] = useState<number>(1);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  const handleAdd = () => {
    if (!selectedSize) {
      setValidationError('Please select a size before adding to bag.');
      return;
    }
    if (!selectedColor && product.colors.length > 0) {
      setValidationError('Please select a color before adding to bag.');
      return;
    }

    setValidationError(null);
    onAddToBag(product, selectedSize, selectedColor, quantity);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2400);
  };

  const relatedProducts = PRODUCTS.filter(
    (p) => p.id !== product.id && (p.category === product.category || p.isStreetwear === product.isStreetwear)
  ).slice(0, 3);

  const images = [product.image, product.secondaryImage].filter(Boolean);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-black/85 backdrop-blur-md">
        {/* Backdrop click handler */}
        <div className="fixed inset-0" onClick={onClose} />

        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-4xl bg-[#0F0F14] border border-[#27272A] rounded-sm overflow-hidden shadow-2xl z-10 max-h-[92vh] flex flex-col"
        >
          {/* Top Bar with Close Action */}
          <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-[#0C0C10] shrink-0">
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-xs text-[#D4AF37] tracking-widest">
                TBC BESPOKE
              </span>
              <span className="text-neutral-600">·</span>
              <span className="text-xs uppercase tracking-wider text-neutral-400">
                {product.category.replace('-', ' ')}
              </span>
            </div>

            <button
              onClick={onClose}
              aria-label="Close product view"
              className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Main Body */}
          <div className="overflow-y-auto p-6 md:p-8 flex-grow">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 items-start">
              {/* Left Column: Image Gallery (6 Cols) */}
              <div className="md:col-span-6 space-y-4">
                {/* Main Large Image */}
                <div className="relative aspect-[3/4] w-full rounded-sm overflow-hidden border border-neutral-800 bg-neutral-900 shadow-inner">
                  <FashionImage
                    src={selectedImage}
                    alt={product.name}
                    fill
                    priority
                    className="object-cover"
                  />
                  {product.tag && (
                    <div className="absolute top-3 left-3 px-3 py-1 bg-black/80 backdrop-blur-sm border border-neutral-800 text-[10px] uppercase tracking-[0.2em] text-[#D4AF37] font-bold">
                      {product.tag}
                    </div>
                  )}
                </div>

                {/* Thumbnails Row */}
                {images.length > 1 && (
                  <div className="flex items-center gap-3">
                    {images.map((img, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedImage(img)}
                        className={`relative w-20 h-24 rounded-sm overflow-hidden border transition-all ${
                          selectedImage === img
                            ? 'border-[#D4AF37] shadow-[0_0_10px_rgba(212,175,55,0.3)]'
                            : 'border-neutral-800 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <FashionImage src={img} alt={`${product.name} view ${idx + 1}`} fill />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: Contiguous Purchase Module (6 Cols) */}
              <div className="md:col-span-6 flex flex-col space-y-6">
                <div>
                  <div className="flex items-center justify-between text-xs uppercase tracking-wider text-neutral-400 mb-2">
                    <span>{STORE_CONFIG.brand.name}</span>
                    <span className="text-[#D4AF37] font-medium">
                      {product.stockStatus === 'low_stock' ? 'Limited Stock' : 'In Stock'}
                    </span>
                  </div>

                  <h2 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-wide">
                    {product.name}
                  </h2>

                  {/* Price */}
                  <div className="mt-3 flex items-baseline gap-3">
                    <span className="font-mono text-2xl font-bold text-[#D4AF37] tabular-nums">
                      {STORE_CONFIG.currency.format(product.price)}
                    </span>
                    {product.originalPrice && (
                      <span className="font-mono text-sm text-neutral-500 line-through tabular-nums">
                        {STORE_CONFIG.currency.format(product.originalPrice)}
                      </span>
                    )}
                    <span className="text-xs text-neutral-400">Inclusive of all taxes</span>
                  </div>
                </div>

                {/* Description */}
                <p className="text-sm text-neutral-300 font-light leading-relaxed border-t border-b border-neutral-800/80 py-4">
                  {product.description}
                </p>

                {/* Size Selection */}
                <div>
                  <div className="flex items-center justify-between text-xs uppercase tracking-wider text-neutral-300 mb-2.5">
                    <span className="font-semibold">Select Size</span>
                    <span className="text-neutral-500">Standard Fit</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => {
                          setSelectedSize(size);
                          setValidationError(null);
                        }}
                        className={`min-w-12 h-10 px-3 text-xs font-mono font-semibold rounded-sm border transition-all ${
                          selectedSize === size
                            ? 'bg-[#D4AF37] text-black border-[#D4AF37]'
                            : 'bg-neutral-900 text-neutral-300 border-neutral-700 hover:border-neutral-500'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Colour Selection */}
                {product.colors.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between text-xs uppercase tracking-wider text-neutral-300 mb-2.5">
                      <span className="font-semibold">
                        Colour: <span className="text-[#D4AF37]">{selectedColor}</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      {product.colors.map((c) => (
                        <button
                          key={c.name}
                          onClick={() => {
                            setSelectedColor(c.name);
                            setValidationError(null);
                          }}
                          className={`flex items-center gap-2 p-1.5 rounded-sm border transition-all ${
                            selectedColor === c.name
                              ? 'border-[#D4AF37] bg-neutral-800'
                              : 'border-transparent hover:border-neutral-700'
                          }`}
                        >
                          <span
                            className="w-5 h-5 rounded-full border border-neutral-600 block shadow-sm"
                            style={{ backgroundColor: c.hex }}
                          />
                          <span className="text-xs text-neutral-300 pr-1">{c.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity Stepper & Stock Check */}
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-neutral-700 rounded-sm bg-neutral-900">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 text-neutral-400 hover:text-white"
                      aria-label="Decrease quantity"
                    >
                      -
                    </button>
                    <span className="px-3 font-mono text-xs font-bold text-white tabular-nums">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-2 text-neutral-400 hover:text-white"
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>
                  <span className="text-xs text-neutral-400">
                    Maximum 5 pcs per boutique order
                  </span>
                </div>

                {/* Validation Error Message */}
                {validationError && (
                  <div className="p-3 bg-red-950/40 border border-red-800/80 rounded-sm text-red-200 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                    <span>{validationError}</span>
                  </div>
                )}

                {/* Primary Action Buttons */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={handleAdd}
                    className="flex-1 py-3.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-all duration-300 flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(212,175,55,0.25)]"
                  >
                    {addedSuccess ? (
                      <>
                        <Check className="w-4 h-4 text-black" />
                        <span>ADDED TO BAG</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4 text-black" />
                        <span>ADD TO BAG</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => onToggleWishlist(product)}
                    aria-label={isWishlisted ? 'Saved to wishlist' : 'Save to wishlist'}
                    className={`p-3.5 border rounded-sm transition-all ${
                      isWishlisted
                        ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#D4AF37]'
                        : 'border-neutral-700 bg-neutral-900 text-neutral-300 hover:text-white hover:border-neutral-500'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#D4AF37]' : ''}`} />
                  </button>
                </div>

                {/* Craftsmanship Highlights */}
                <div className="pt-4 border-t border-neutral-850 space-y-2 text-xs text-neutral-400">
                  <div className="font-semibold text-neutral-300 uppercase tracking-wider mb-2">
                    Material & Craftsmanship
                  </div>
                  <ul className="space-y-1.5 list-disc list-inside">
                    {product.details.map((detail, idx) => (
                      <li key={idx} className="font-light">
                        {detail}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Related Pieces Strip */}
            {relatedProducts.length > 0 && (
              <div className="mt-12 pt-8 border-t border-neutral-800">
                <span className="text-xs uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-4">
                  COMPLETE THE LOOK
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {relatedProducts.map((rel) => (
                    <div
                      key={rel.id}
                      onClick={() => onSelectProduct(rel)}
                      className="p-3 bg-neutral-900/60 border border-neutral-800 hover:border-neutral-600 rounded-sm cursor-pointer transition-all flex items-center gap-3 group"
                    >
                      <div className="relative w-14 h-18 rounded overflow-hidden shrink-0 bg-neutral-800">
                        <FashionImage src={rel.image} alt={rel.name} fill />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-white group-hover:text-[#D4AF37] transition-colors truncate">
                          {rel.name}
                        </h4>
                        <span className="font-mono text-xs text-neutral-400 tabular-nums">
                          {STORE_CONFIG.currency.format(rel.price)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
