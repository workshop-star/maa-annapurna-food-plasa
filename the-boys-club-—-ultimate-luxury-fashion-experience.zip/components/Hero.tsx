'use client';

import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown, Phone, Sparkles, Box } from 'lucide-react';
import { STORE_CONFIG } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

interface HeroProps {
  onExploreCollection: () => void;
  onDiscoverShowroom: () => void;
}

export function Hero({ onExploreCollection, onDiscoverShowroom }: HeroProps) {
  const headlineWords1 = STORE_CONFIG.brand.heroHeadlinePart1.split(' ');
  const headlineWords2 = STORE_CONFIG.brand.heroHeadlinePart2.split(' ');

  return (
    <section
      id="home"
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-[#070709] pt-24 pb-16 lg:pt-0 lg:pb-0"
    >
      {/* Background Cinematic Atmosphere */}
      <div className="absolute inset-0 z-0 select-none pointer-events-none">
        {/* Radial ambient champagne light glow */}
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-[radial-gradient(circle,rgba(212,175,55,0.08)_0%,transparent_70%)] blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-[600px] h-[600px] bg-[radial-gradient(circle,rgba(30,30,40,0.4)_0%,transparent_70%)] blur-2xl" />
        {/* Subtle grid texture */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `radial-gradient(rgba(255,255,255,0.8) 1px, transparent 1px)`,
            backgroundSize: '36px 36px',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-24">
        {/* Asymmetric Editorial Hero Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Bold Editorial Typography & Functional CTAs (7 Cols) */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
            {/* Editorial Location & Identity Label */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-3 text-xs uppercase tracking-[0.35em] text-[#D4AF37] font-semibold"
            >
              <span>{STORE_CONFIG.location.name}</span>
              <span className="text-neutral-600" aria-hidden="true">·</span>
              <span>AUTUMN / WINTER 2026</span>
            </motion.div>

            {/* Word-by-Word Animated Headline */}
            <div className="space-y-1">
              <h1 className="font-display text-4xl sm:text-6xl xl:text-7xl font-black text-white tracking-tight leading-[1.05] text-balance">
                <span className="block overflow-hidden">
                  {headlineWords1.map((word, i) => (
                    <motion.span
                      key={i}
                      initial={{ y: 60, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ duration: 0.7, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                      className="inline-block mr-3"
                    >
                      {word}
                    </motion.span>
                  ))}
                </span>
                <span className="block overflow-hidden gold-gradient-text">
                  {headlineWords2.map((word, i) => (
                    <motion.span
                      key={i}
                      initial={{ y: 60, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ duration: 0.7, delay: (headlineWords1.length + i) * 0.1, ease: [0.16, 1, 0.3, 1] }}
                      className="inline-block mr-3"
                    >
                      {word}
                    </motion.span>
                  ))}
                </span>
              </h1>
            </div>

            {/* Supporting Copy */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="text-base sm:text-lg text-neutral-300 font-light max-w-xl leading-relaxed"
            >
              {STORE_CONFIG.brand.subheading} Engineered silhouettes, 280 GSM heavyweight cottons, raw selvedge denim, and architectural casual wear designed for modern presence.
            </motion.p>

            {/* 3 Working Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.65 }}
              className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4"
            >
              {/* Primary: Explore Collection */}
              <button
                onClick={onExploreCollection}
                className="px-6 py-3.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-all duration-300 shadow-[0_0_20px_rgba(212,175,55,0.25)] hover:shadow-[0_0_25px_rgba(212,175,55,0.4)] whitespace-nowrap"
              >
                EXPLORE COLLECTION
              </button>

              {/* Secondary: Discover Showroom */}
              <button
                onClick={onDiscoverShowroom}
                className="px-6 py-3.5 bg-neutral-900/80 hover:bg-neutral-800 text-white hover:text-[#D4AF37] border border-neutral-700 hover:border-[#D4AF37] text-xs font-semibold uppercase tracking-[0.2em] rounded-sm transition-all duration-300 flex items-center gap-2 whitespace-nowrap"
              >
                <Box className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>DISCOVER THE SHOWROOM</span>
              </button>

              {/* Tertiary: Call the Store */}
              <a
                href={`tel:${STORE_CONFIG.location.phone}`}
                className="px-5 py-3.5 bg-transparent hover:bg-white/5 text-neutral-300 hover:text-white border border-neutral-800 text-xs font-semibold uppercase tracking-[0.2em] rounded-sm transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>CALL THE STORE</span>
              </a>
            </motion.div>

            {/* Quiet Trust Verification Strip */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.85 }}
              className="pt-4 flex items-center gap-6 text-xs text-neutral-400"
            >
              <div className="flex items-center gap-1.5">
                <span className="text-[#D4AF37] font-bold text-sm tracking-widest">★★★★★</span>
                <span className="font-semibold text-neutral-200">5.0</span>
              </div>
              <span className="text-neutral-700">·</span>
              <span>{STORE_CONFIG.location.ratingText}</span>
              <span className="text-neutral-700 hidden sm:inline">·</span>
              <span className="hidden sm:inline text-neutral-400">Gondalipokhar, Angara</span>
            </motion.div>
          </div>

          {/* Right Column: High-Fashion Cinematic Visual Composition (5 Cols) */}
          <div className="lg:col-span-5 relative mt-6 lg:mt-0">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.3, ease: 'easeOut' }}
              className="relative mx-auto max-w-[440px] lg:max-w-none"
            >
              {/* Asymmetric Outer Frame */}
              <div className="relative aspect-[3/4] w-full rounded-sm overflow-hidden border border-[#27272A] shadow-2xl group">
                <FashionImage
                  src="https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?q=80&w=1200&auto=format&fit=crop"
                  alt="THE BOYS CLUB Luxury Menswear Campaign"
                  fill
                  priority
                  className="group-hover:scale-105 transition-transform duration-1000"
                />

                {/* Scrim overlay for depth */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />

                {/* Floating Floating Editorial Labels */}
                <div className="absolute top-4 left-4 z-10 px-3 py-1.5 bg-black/75 backdrop-blur-sm border border-neutral-800 text-[10px] uppercase tracking-[0.25em] text-[#D4AF37] font-bold">
                  DROP 01 // 2026
                </div>

                <div className="absolute bottom-4 left-4 right-4 z-10 flex items-end justify-between">
                  <div>
                    <span className="text-[11px] uppercase tracking-widest text-neutral-400 block">
                      FEATURED LOOK
                    </span>
                    <span className="font-display text-sm font-bold text-white tracking-wider">
                      Onyx Bomber & Selvedge Fit
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-sm text-[#D4AF37] font-semibold tabular-nums">
                      ₹4,999
                    </span>
                  </div>
                </div>
              </div>

              {/* Offset Accent Decorative Frame */}
              <div className="absolute -bottom-3 -right-3 -z-10 w-full h-full border border-[#D4AF37]/30 rounded-sm pointer-events-none hidden sm:block" />
            </motion.div>
          </div>
        </div>
      </div>

      {/* Refined Scroll Down Indicator */}
      <a
        href="#collection"
        aria-label="Scroll down to fashion collections"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-1 text-[10px] uppercase tracking-[0.25em] text-neutral-400 hover:text-[#D4AF37] transition-colors"
      >
        <span>DISCOVER</span>
        <ArrowDown className="w-3.5 h-3.5 animate-bounce" />
      </a>
    </section>
  );
}
