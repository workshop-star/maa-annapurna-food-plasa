'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Eye, RotateCw, Maximize2, Minimize2, Sparkles, Navigation, Layers, ChevronDown, ChevronUp } from 'lucide-react';

interface ShowroomProps {
  onExploreCollection?: () => void;
}

type CameraPresetKey = 'entrance' | 'menswear' | 'newarrivals' | 'center';

export function Showroom3D({ onExploreCollection }: ShowroomProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [activePreset, setActivePreset] = useState<CameraPresetKey>('entrance');
  const activePresetRef = useRef<CameraPresetKey>('entrance');
  const [isCinemaMode, setIsCinemaMode] = useState(false);
  const [isAutoRotating, setIsAutoRotating] = useState(true);
  const [lightingPreset, setLightingPreset] = useState<'warm' | 'runway' | 'noir'>('warm');
  const [isLoaded, setIsLoaded] = useState(false);
  const [hoveredGarment, setHoveredGarment] = useState<string | null>(null);

  // References to keep state synced without re-triggering Three.js render loop setup
  const sceneStateRef = useRef({
    targetCamPos: new THREE.Vector3(0, 2.2, 7.5),
    targetLookAt: new THREE.Vector3(0, 1.4, 0),
    currentLookAt: new THREE.Vector3(0, 1.4, 0),
    isAutoRotating: true,
    orbitAngle: 0,
    lightingMode: 'warm',
  });

  // Sync ref with state
  useEffect(() => {
    sceneStateRef.current.isAutoRotating = isAutoRotating;
  }, [isAutoRotating]);

  const setCameraPreset = (key: CameraPresetKey) => {
    setActivePreset(key);
    activePresetRef.current = key;
    if (key === 'entrance') {
      sceneStateRef.current.targetCamPos.set(0, 2.0, 7.0);
      sceneStateRef.current.targetLookAt.set(0, 1.2, 0);
    } else if (key === 'menswear') {
      // Look towards the left clothing rack & mannequin
      sceneStateRef.current.targetCamPos.set(-2.4, 1.7, 2.8);
      sceneStateRef.current.targetLookAt.set(-3.2, 1.4, -0.5);
    } else if (key === 'newarrivals') {
      // Look towards the designer display pedestal & right rail
      sceneStateRef.current.targetCamPos.set(2.4, 1.7, 2.8);
      sceneStateRef.current.targetLookAt.set(3.2, 1.4, -0.5);
    } else if (key === 'center') {
      // Center hero pedestal view
      sceneStateRef.current.targetCamPos.set(0, 1.8, 3.8);
      sceneStateRef.current.targetLookAt.set(0, 1.3, 0);
    }
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let animationFrameId: number;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || 550;

    // 1. Scene & Renderer setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0d);
    scene.fog = new THREE.FogExp2(0x0a0a0d, 0.045);

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 50);
    camera.position.set(0, 2.0, 7.0);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 2. Studio Environment Reflection via RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 3. Studio Lighting Rig
    const ambientLight = new THREE.HemisphereLight(0xfff5e6, 0x14141c, 0.65);
    scene.add(ambientLight);

    // Warm architectural spotlight 1 (Key light onto central display)
    const keySpot = new THREE.SpotLight(0xffecd1, 2.8, 20, Math.PI / 4, 0.4, 1);
    keySpot.position.set(0, 5.5, 3.5);
    keySpot.castShadow = true;
    keySpot.shadow.bias = -0.0005;
    keySpot.shadow.mapSize.width = 1024;
    keySpot.shadow.mapSize.height = 1024;
    scene.add(keySpot);

    // Left boutique rail accent light
    const leftSpot = new THREE.SpotLight(0xd4af37, 2.2, 16, Math.PI / 5, 0.3, 1);
    leftSpot.position.set(-3.5, 4.5, 1);
    leftSpot.target.position.set(-3.5, 1.2, -0.5);
    scene.add(leftSpot);
    scene.add(leftSpot.target);

    // Right boutique rail accent light
    const rightSpot = new THREE.SpotLight(0xffffff, 2.0, 16, Math.PI / 5, 0.3, 1);
    rightSpot.position.set(3.5, 4.5, 1);
    rightSpot.target.position.set(3.5, 1.2, -0.5);
    scene.add(rightSpot);
    scene.add(rightSpot.target);

    // 4. Procedural Boutique Materials
    // Polished dark stone terrazzo floor
    const floorGeo = new THREE.PlaneGeometry(24, 24);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x111114,
      roughness: 0.15,
      metalness: 0.25,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    // Floor Contact Shadow / Area Rug under Central Pedestal
    const rugGeo = new THREE.CircleGeometry(2.8, 48);
    const rugMat = new THREE.MeshStandardMaterial({
      color: 0x070709,
      roughness: 0.85,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    const rugMesh = new THREE.Mesh(rugGeo, rugMat);
    rugMesh.rotation.x = -Math.PI / 2;
    rugMesh.position.set(0, 0.005, 0);
    rugMesh.receiveShadow = true;
    scene.add(rugMesh);

    // Back Wall - Matte Charcoal Plaster with Gold Inset Trim
    const backWallGroup = new THREE.Group();
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x141419, roughness: 0.75 });
    const wallGeo = new THREE.BoxGeometry(16, 6, 0.4);
    const wallMesh = new THREE.Mesh(wallGeo, wallMat);
    wallMesh.position.set(0, 3, -3.8);
    wallMesh.receiveShadow = true;
    backWallGroup.add(wallMesh);

    // Gold Trim inlay bar on back wall
    const trimGeo = new THREE.BoxGeometry(14, 0.04, 0.02);
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37,
      metalness: 0.9,
      roughness: 0.2,
    });
    const trimMesh = new THREE.Mesh(trimGeo, goldMat);
    trimMesh.position.set(0, 4.2, -3.58);
    backWallGroup.add(trimMesh);

    // Back wall large boutique architectural mirror with bronze frame
    const mirrorFrameGeo = new THREE.BoxGeometry(3.6, 4.2, 0.08);
    const mirrorFrameMat = new THREE.MeshStandardMaterial({ color: 0x8a7029, metalness: 0.85, roughness: 0.3 });
    const mirrorFrame = new THREE.Mesh(mirrorFrameGeo, mirrorFrameMat);
    mirrorFrame.position.set(0, 2.3, -3.56);
    backWallGroup.add(mirrorFrame);

    const mirrorGlassGeo = new THREE.PlaneGeometry(3.3, 3.9);
    const mirrorGlassMat = new THREE.MeshStandardMaterial({
      color: 0x24242e,
      roughness: 0.05,
      metalness: 0.95,
    });
    const mirrorGlass = new THREE.Mesh(mirrorGlassGeo, mirrorGlassMat);
    mirrorGlass.position.set(0, 2.3, -3.51);
    backWallGroup.add(mirrorGlass);

    // Illuminated "THE BOYS CLUB" Backplate Monogram
    const logoPlateGeo = new THREE.BoxGeometry(2.4, 0.6, 0.04);
    const logoPlateMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      metalness: 0.7,
      roughness: 0.3,
    });
    const logoPlate = new THREE.Mesh(logoPlateGeo, logoPlateMat);
    logoPlate.position.set(0, 4.8, -3.56);
    backWallGroup.add(logoPlate);

    scene.add(backWallGroup);

    // Left Wall & Right Wall architectural pillars
    const pillarGeo = new THREE.BoxGeometry(0.8, 6, 0.8);
    const leftPillar = new THREE.Mesh(pillarGeo, wallMat);
    leftPillar.position.set(-6, 3, 0);
    scene.add(leftPillar);

    const rightPillar = new THREE.Mesh(pillarGeo, wallMat);
    rightPillar.position.set(6, 3, 0);
    scene.add(rightPillar);

    // 5. Central Exhibition Pedestal & Fashion Mannequin (3-12 Part Composite Model)
    const centralGroup = new THREE.Group();

    // Pedestal Base (Brushed Charcoal & Gold Accent Rim)
    const pedBaseGeo = new THREE.CylinderGeometry(1.2, 1.25, 0.45, 36);
    const pedMat = new THREE.MeshStandardMaterial({ color: 0x17171d, roughness: 0.35, metalness: 0.4 });
    const pedMesh = new THREE.Mesh(pedBaseGeo, pedMat);
    pedMesh.position.y = 0.225;
    pedMesh.castShadow = true;
    pedMesh.receiveShadow = true;
    centralGroup.add(pedMesh);

    const pedRimGeo = new THREE.CylinderGeometry(1.22, 1.22, 0.04, 36);
    const pedRim = new THREE.Mesh(pedRimGeo, goldMat);
    pedRim.position.y = 0.44;
    centralGroup.add(pedRim);

    // Tailored Menswear Mannequin
    const mannequinGroup = new THREE.Group();
    mannequinGroup.position.set(0, 0.45, 0);

    // Mannequin support rod
    const rodGeo = new THREE.CylinderGeometry(0.025, 0.025, 1.1, 16);
    const rodMesh = new THREE.Mesh(rodGeo, goldMat);
    rodMesh.position.y = 0.55;
    mannequinGroup.add(rodMesh);

    // Mannequin Torso (Luxury tailored silhouette)
    const torsoGeo = new THREE.CylinderGeometry(0.24, 0.18, 0.8, 20);
    const torsoMat = new THREE.MeshStandardMaterial({
      color: 0x1f1f26,
      roughness: 0.6,
      metalness: 0.1,
    });
    const torsoMesh = new THREE.Mesh(torsoGeo, torsoMat);
    torsoMesh.position.y = 1.35;
    torsoMesh.scale.set(1.2, 1, 0.7);
    torsoMesh.castShadow = true;
    mannequinGroup.add(torsoMesh);

    // Mannequin Chest/Shoulder Cap (Broad drop-shoulder structure)
    const chestGeo = new THREE.BoxGeometry(0.58, 0.22, 0.32);
    const chestMat = new THREE.MeshStandardMaterial({ color: 0x2a2a35, roughness: 0.5 });
    const chestMesh = new THREE.Mesh(chestGeo, chestMat);
    chestMesh.position.y = 1.65;
    chestMesh.castShadow = true;
    mannequinGroup.add(chestMesh);

    // Mannequin Neck & Brushed Gold Crown Finial
    const neckGeo = new THREE.CylinderGeometry(0.08, 0.09, 0.16, 16);
    const neckMesh = new THREE.Mesh(neckGeo, torsoMat);
    neckMesh.position.y = 1.83;
    mannequinGroup.add(neckMesh);

    const crownGeo = new THREE.SphereGeometry(0.09, 20, 20);
    const crownMesh = new THREE.Mesh(crownGeo, goldMat);
    crownMesh.position.y = 1.95;
    crownMesh.scale.set(1, 0.6, 1);
    mannequinGroup.add(crownMesh);

    // Mannequin Cropped Bomber Layer (Open front aesthetic)
    const jacketLeftGeo = new THREE.BoxGeometry(0.2, 0.65, 0.32);
    const jacketMat = new THREE.MeshStandardMaterial({ color: 0x0c0c0e, roughness: 0.25, metalness: 0.3 });
    const jacketLeft = new THREE.Mesh(jacketLeftGeo, jacketMat);
    jacketLeft.position.set(-0.24, 1.35, 0.02);
    jacketLeft.castShadow = true;
    mannequinGroup.add(jacketLeft);

    const jacketRight = jacketLeft.clone();
    jacketRight.position.x = 0.24;
    mannequinGroup.add(jacketRight);

    centralGroup.add(mannequinGroup);
    scene.add(centralGroup);

    // 6. Left Black Metal Clothing Rail (T-Shirts & Overshirts)
    const leftRailGroup = new THREE.Group();
    leftRailGroup.position.set(-3.5, 0, -0.6);

    // Sturdy modern architectural steel base & vertical posts
    const railMat = new THREE.MeshStandardMaterial({ color: 0x17171a, metalness: 0.85, roughness: 0.2 });
    const railBaseGeo = new THREE.BoxGeometry(0.4, 0.04, 3.2);
    const railBaseL = new THREE.Mesh(railBaseGeo, railMat);
    railBaseL.position.set(0, 0.02, 0);
    leftRailGroup.add(railBaseL);

    const postGeo = new THREE.CylinderGeometry(0.022, 0.022, 1.85, 16);
    const postL1 = new THREE.Mesh(postGeo, railMat);
    postL1.position.set(0, 0.925, -1.3);
    postL1.castShadow = true;
    leftRailGroup.add(postL1);

    const postL2 = new THREE.Mesh(postGeo, railMat);
    postL2.position.set(0, 0.925, 1.3);
    postL2.castShadow = true;
    leftRailGroup.add(postL2);

    // Top gold/brass horizontal hanger bar
    const barGeo = new THREE.CylinderGeometry(0.018, 0.018, 2.7, 16);
    const barMesh = new THREE.Mesh(barGeo, goldMat);
    barMesh.rotation.x = Math.PI / 2;
    barMesh.position.set(0, 1.82, 0);
    leftRailGroup.add(barMesh);

    // Hanging garments (6 curated shirts & tees on hangers)
    const hangerGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.34, 12);
    const garmentColors = [0x111113, 0xf0ece1, 0x2b2b33, 0x473e33, 0x1f2b38, 0x131316];
    const garmentMeshes: THREE.Mesh[] = [];

    for (let i = 0; i < 6; i++) {
      const zOffset = -1.0 + i * 0.4;
      // Small hanger
      const hanger = new THREE.Mesh(hangerGeo, goldMat);
      hanger.position.set(0, 1.8, zOffset);
      hanger.rotation.y = Math.PI / 2;
      leftRailGroup.add(hanger);

      // Hanging garment drape
      const gGeo = new THREE.BoxGeometry(0.09, 0.85, 0.32);
      const gMat = new THREE.MeshStandardMaterial({
        color: garmentColors[i],
        roughness: 0.65,
        metalness: 0.1,
      });
      const gMesh = new THREE.Mesh(gGeo, gMat);
      gMesh.position.set(0, 1.32, zOffset);
      gMesh.castShadow = true;
      leftRailGroup.add(gMesh);
      garmentMeshes.push(gMesh);
    }
    scene.add(leftRailGroup);

    // 7. Right Designer Shelving Unit & Folded Garments Display
    const rightShelfGroup = new THREE.Group();
    rightShelfGroup.position.set(3.6, 0, -0.6);

    // 3 Floating dark oak shelves
    const shelfGeo = new THREE.BoxGeometry(0.8, 0.05, 2.6);
    const shelfMat = new THREE.MeshStandardMaterial({ color: 0x181412, roughness: 0.4 });
    const shelfBrassMat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.8, roughness: 0.3 });

    for (let s = 0; s < 3; s++) {
      const sY = 0.6 + s * 0.55;
      const shelf = new THREE.Mesh(shelfGeo, shelfMat);
      shelf.position.set(0, sY, 0);
      shelf.castShadow = true;
      shelf.receiveShadow = true;
      rightShelfGroup.add(shelf);

      // Folded luxury shirts on shelf
      for (let f = 0; f < 3; f++) {
        const stackGeo = new THREE.BoxGeometry(0.35, 0.08, 0.45);
        const stackColor = [0x121214, 0xe8e4d8, 0x2f343b][(s + f) % 3];
        const stackMat = new THREE.MeshStandardMaterial({ color: stackColor, roughness: 0.7 });
        const stack = new THREE.Mesh(stackGeo, stackMat);
        stack.position.set(-0.1 + (f % 2) * 0.25, sY + 0.065, -0.7 + f * 0.7);
        stack.castShadow = true;
        rightShelfGroup.add(stack);
      }
    }

    // Shelf vertical gold framing rods
    for (let r = 0; r < 4; r++) {
      const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 2.1, 16), shelfBrassMat);
      rod.position.set((r % 2 === 0 ? -0.38 : 0.38), 1.05, (r < 2 ? -1.25 : 1.25));
      rightShelfGroup.add(rod);
    }
    scene.add(rightShelfGroup);

    // 8. Entrance Glass Partitions with Champagne Frosted Borders
    const glassGroup = new THREE.Group();
    const glassGeo = new THREE.BoxGeometry(1.6, 3.2, 0.04);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.9,
      opacity: 0.4,
      transparent: true,
      roughness: 0.1,
      ior: 1.5,
      metalness: 0.1,
    });
    const glassL = new THREE.Mesh(glassGeo, glassMat);
    glassL.position.set(-3.2, 1.6, 4.8);
    glassGroup.add(glassL);

    const glassR = new THREE.Mesh(glassGeo, glassMat);
    glassR.position.set(3.2, 1.6, 4.8);
    glassGroup.add(glassR);

    // Brass handles on glass doors
    const handleGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.8, 16);
    const handleL = new THREE.Mesh(handleGeo, goldMat);
    handleL.position.set(-2.5, 1.4, 4.85);
    glassGroup.add(handleL);

    const handleR = new THREE.Mesh(handleGeo, goldMat);
    handleR.position.set(2.5, 1.4, 4.85);
    glassGroup.add(handleR);

    scene.add(glassGroup);

    setIsLoaded(true);

    // 9. Silky Smooth Animation & Render Loop with Exponential Damping
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = Math.min(clock.getDelta(), 0.1);

      // Subtle rotation on central pedestal mannequin
      centralGroup.rotation.y += delta * 0.12;

      // Gentle hanger sway on left rack
      garmentMeshes.forEach((mesh, idx) => {
        mesh.rotation.z = Math.sin(clock.getElapsedTime() * 1.5 + idx * 0.8) * 0.02;
      });

      // Camera preset interpolation with frame-rate independent damp
      const state = sceneStateRef.current;

      if (state.isAutoRotating && activePresetRef.current === 'entrance') {
        state.orbitAngle += delta * 0.15;
        const radius = 6.8;
        const currentTargetX = Math.sin(state.orbitAngle) * (radius * 0.35);
        camera.position.x = THREE.MathUtils.damp(camera.position.x, currentTargetX, 1.5, delta);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, 6.8, 1.5, delta);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, 2.0, 1.5, delta);
      } else {
        camera.position.x = THREE.MathUtils.damp(camera.position.x, state.targetCamPos.x, 2.5, delta);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, state.targetCamPos.y, 2.5, delta);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, state.targetCamPos.z, 2.5, delta);
      }

      state.currentLookAt.x = THREE.MathUtils.damp(state.currentLookAt.x, state.targetLookAt.x, 2.5, delta);
      state.currentLookAt.y = THREE.MathUtils.damp(state.currentLookAt.y, state.targetLookAt.y, 2.5, delta);
      state.currentLookAt.z = THREE.MathUtils.damp(state.currentLookAt.z, state.targetLookAt.z, 2.5, delta);

      camera.lookAt(state.currentLookAt);

      renderer.render(scene, camera);
    };

    animate();

    // 10. Responsive Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      renderer.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      wallGeo.dispose();
      wallMat.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <section id="showroom" className="relative w-full bg-[#08080A] py-16 md:py-24 border-t border-[#1F1F24] overflow-hidden">
      {/* Editorial Header */}
      <div className="max-w-7xl mx-auto px-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <span className="text-xs uppercase tracking-[0.3em] text-[#D4AF37] font-semibold block mb-2">
            INTERACTIVE 3D BOUTIQUE
          </span>
          <h2 className="font-display text-3xl md:text-5xl font-black text-white tracking-wide">
            THE GONDALIPOKHAR SHOWROOM
          </h2>
          <p className="text-sm md:text-base text-neutral-400 mt-2 max-w-xl font-light">
            Step directly inside our flagship retail space. Rotate the view, inspect architectural clothing rails, and preview bespoke menswear displays in real-time 3D.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={`px-4 py-2 text-xs uppercase tracking-wider rounded-sm flex items-center gap-2 border transition-colors ${
              isAutoRotating
                ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#D4AF37]'
                : 'border-neutral-800 text-neutral-400 hover:text-white'
            }`}
          >
            <RotateCw className={`w-3.5 h-3.5 ${isAutoRotating ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            <span>Auto Orbit</span>
          </button>

          <button
            onClick={() => setIsCinemaMode(!isCinemaMode)}
            className="p-2 text-neutral-400 hover:text-[#D4AF37] border border-neutral-800 rounded-sm transition-colors"
            title={isCinemaMode ? 'Expand view' : 'Cinema mode'}
            aria-label="Toggle full view"
          >
            {isCinemaMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 3D Scene Viewport Container */}
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div
          className={`relative w-full rounded-sm overflow-hidden border border-neutral-800/80 bg-[#0A0A0D] transition-all duration-500 shadow-2xl ${
            isCinemaMode ? 'h-[750px]' : 'h-[520px] md:h-[620px]'
          }`}
        >
          {/* Isolated WebGL Canvas Container */}
          <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

          {/* Loading Indicator */}
          {!isLoaded && (
            <div className="absolute inset-0 bg-[#0A0A0D] flex flex-col items-center justify-center gap-3 z-30">
              <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
              <span className="text-xs uppercase tracking-widest text-[#D4AF37]/80 font-display">
                Rendering Showroom Space...
              </span>
            </div>
          )}

          {/* Unobstructed Top Minimal Badge */}
          <div className="absolute top-4 left-4 z-20 pointer-events-none flex items-center gap-2 px-3 py-1.5 bg-black/70 backdrop-blur-sm border border-neutral-800 rounded-sm">
            <span className="font-display font-bold text-xs text-[#D4AF37] tracking-widest">TBC</span>
            <span className="text-[10px] text-neutral-400 uppercase tracking-wider">Spatial Boutique Engine</span>
          </div>

          {/* Viewport Floating Watermark / Coordinates */}
          <div className="absolute top-4 right-4 z-20 pointer-events-none text-right">
            <span className="text-[10px] font-mono tracking-widest text-neutral-500 uppercase block">
              LAT 23.414° N · LON 85.512° E
            </span>
            <span className="text-[9px] uppercase tracking-wider text-[#D4AF37]/70">
              Angara, Jharkhand
            </span>
          </div>

          {/* Three.js Skill Mandated Ergonomic Unified Collapsible Bottom Dock (Zero Center Viewport Occlusion) */}
          <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-[840px] pointer-events-auto">
            <div className="bg-[#0C0C10]/90 backdrop-blur-md border border-[#27272A] rounded-md p-3 md:p-3.5 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-3">
              {/* Presets Navigation Bar */}
              <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto scrollbar-none pb-1 md:pb-0">
                <button
                  onClick={() => setCameraPreset('entrance')}
                  className={`px-3 py-1.5 text-xs font-medium uppercase tracking-wider rounded-sm transition-all whitespace-nowrap shrink-0 ${
                    activePreset === 'entrance'
                      ? 'bg-[#D4AF37] text-black font-semibold'
                      : 'text-neutral-300 hover:text-white hover:bg-neutral-800/80'
                  }`}
                >
                  ENTER SHOWROOM
                </button>

                <button
                  onClick={() => setCameraPreset('menswear')}
                  className={`px-3 py-1.5 text-xs font-medium uppercase tracking-wider rounded-sm transition-all whitespace-nowrap shrink-0 ${
                    activePreset === 'menswear'
                      ? 'bg-[#D4AF37] text-black font-semibold'
                      : 'text-neutral-300 hover:text-white hover:bg-neutral-800/80'
                  }`}
                >
                  EXPLORE MEN&apos;S STYLE
                </button>

                <button
                  onClick={() => setCameraPreset('newarrivals')}
                  className={`px-3 py-1.5 text-xs font-medium uppercase tracking-wider rounded-sm transition-all whitespace-nowrap shrink-0 ${
                    activePreset === 'newarrivals'
                      ? 'bg-[#D4AF37] text-black font-semibold'
                      : 'text-neutral-300 hover:text-white hover:bg-neutral-800/80'
                  }`}
                >
                  VIEW NEW ARRIVALS
                </button>

                <button
                  onClick={() => setCameraPreset('center')}
                  className={`px-3 py-1.5 text-xs font-medium uppercase tracking-wider rounded-sm transition-all whitespace-nowrap shrink-0 ${
                    activePreset === 'center'
                      ? 'bg-[#D4AF37] text-black font-semibold'
                      : 'text-neutral-300 hover:text-white hover:bg-neutral-800/80'
                  }`}
                >
                  HERO PEDESTAL
                </button>
              </div>

              {/* Action route button */}
              <div className="flex items-center gap-2 shrink-0 w-full md:w-auto justify-end pt-2 md:pt-0 border-t md:border-t-0 border-neutral-800">
                <a
                  href="#collection"
                  onClick={onExploreCollection}
                  className="px-4 py-1.5 text-xs font-semibold uppercase tracking-wider bg-white text-black hover:bg-[#D4AF37] hover:text-black rounded-sm transition-colors whitespace-nowrap"
                >
                  RETURN TO SHOP
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
