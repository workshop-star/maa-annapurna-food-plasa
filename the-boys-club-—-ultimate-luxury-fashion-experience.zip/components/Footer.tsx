'use client';

import React from 'react';
import { ArrowUp, Play } from 'lucide-react';
import { STORE_CONFIG } from '@/lib/config';

interface FooterProps {
  onReplayIntro?: () => void;
}

export function Footer({ onReplayIntro }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#050507] border-t border-neutral-900 text-neutral-400 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-neutral-900">
          {/* Brand Col (5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-sm bg-[#141419] border border-[#D4AF37]/50 flex items-center justify-center">
                <span className="font-display font-black text-xs text-[#D4AF37] tracking-wider">
                  {STORE_CONFIG.brand.monogram}
                </span>
              </div>
              <span className="font-display text-lg font-bold tracking-[0.25em] text-white">
                {STORE_CONFIG.brand.name}
              </span>
            </div>
            <p className="text-xs text-neutral-400 max-w-sm leading-relaxed font-light">
              &ldquo;{STORE_CONFIG.brand.tagline}&rdquo; Luxury streetwear, 280 GSM heavyweight cottons, raw selvedge denim and architectural silhouettes.
            </p>
            <div className="text-xs text-neutral-400 space-y-1 pt-2">
              <p className="text-white font-medium">{STORE_CONFIG.location.name}</p>
              <p>{STORE_CONFIG.location.address}</p>
              <p className="font-mono text-[#D4AF37]">Tel: {STORE_CONFIG.location.phone}</p>
            </div>
          </div>

          {/* Nav Links (3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <span className="font-display text-xs tracking-[0.25em] text-white uppercase font-bold block">
              COLLECTIONS
            </span>
            <ul className="space-y-2 text-xs font-light">
              <li>
                <a href="#collection" className="hover:text-[#D4AF37] transition-colors">
                  Oversized T-Shirts
                </a>
              </li>
              <li>
                <a href="#collection" className="hover:text-[#D4AF37] transition-colors">
                  Premium Poplin Shirts
                </a>
              </li>
              <li>
                <a href="#collection" className="hover:text-[#D4AF37] transition-colors">
                  Raw Selvedge Denim
                </a>
              </li>
              <li>
                <a href="#collection" className="hover:text-[#D4AF37] transition-colors">
                  Architectural Jackets
                </a>
              </li>
              <li>
                <a href="#collection" className="hover:text-[#D4AF37] transition-colors">
                  Tailored Trousers
                </a>
              </li>
              <li>
                <a href="#collection" className="hover:text-[#D4AF37] transition-colors">
                  Festive Traditional Wear
                </a>
              </li>
            </ul>
          </div>

          {/* Boutique Experience (4 cols) */}
          <div className="md:col-span-4 space-y-4">
            <span className="font-display text-xs tracking-[0.25em] text-white uppercase font-bold block">
              EXPERIENCE
            </span>
            <p className="text-xs text-neutral-400 font-light leading-relaxed">
              Explore the virtual 3D boutique showroom or visit the physical flagship store in Gondalipokhar.
            </p>
            <div className="flex flex-col gap-2 pt-1">
              <a
                href="#showroom"
                className="text-xs font-semibold uppercase tracking-wider text-[#D4AF37] hover:underline"
              >
                Launch 3D Showroom →
              </a>
              {onReplayIntro && (
                <button
                  onClick={onReplayIntro}
                  className="text-xs font-semibold uppercase tracking-wider text-neutral-300 hover:text-white flex items-center gap-1.5 self-start"
                >
                  <Play className="w-3 h-3 text-[#D4AF37]" />
                  <span>Replay Cinematic Opening Sequence</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
          <div>
            © {new Date().getFullYear()} {STORE_CONFIG.brand.name}. {STORE_CONFIG.location.name}. All rights reserved.
            <span className="block text-[11px] text-neutral-400 mt-1">
              Client demonstration website for luxury menswear boutique presentation.
            </span>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-neutral-400 hover:text-[#D4AF37] uppercase tracking-wider text-xs font-medium transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
}
