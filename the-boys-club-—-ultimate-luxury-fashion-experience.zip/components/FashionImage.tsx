'use client';

import React, { useState } from 'react';
import Image from 'next/image';

interface FashionImageProps {
  src: string;
  alt: string;
  fill?: boolean;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
  sizes?: string;
}

export function FashionImage({
  src,
  alt,
  fill = false,
  width,
  height,
  className = '',
  priority = false,
  sizes,
}: FashionImageProps) {
  const [hasError, setHasError] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`relative flex items-center justify-center bg-gradient-to-br from-[#121216] via-[#1A1A22] to-[#0A0A0C] border border-[#27272A] overflow-hidden ${
          fill ? 'w-full h-full' : ''
        } ${className}`}
        style={!fill && width && height ? { width, height } : undefined}
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.08)_0%,transparent_70%)]" />
        <div className="text-center p-4 z-10">
          <span className="font-display text-2xl tracking-[0.25em] text-[#D4AF37] block font-bold">
            TBC
          </span>
          <span className="text-[11px] tracking-widest uppercase text-neutral-400 mt-1 block">
            THE BOYS CLUB
          </span>
          <span className="text-[10px] text-neutral-500 line-clamp-1 mt-0.5 max-w-[160px]">
            {alt}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`relative overflow-hidden bg-[#121216] ${
        fill ? 'w-full h-full' : ''
      } ${className}`}
    >
      {/* Loading Skeleton */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-neutral-900 animate-pulse z-10 flex items-center justify-center">
          <span className="font-display text-xs tracking-widest text-[#D4AF37]/40">
            TBC
          </span>
        </div>
      )}

      {fill ? (
        <Image
          src={src}
          alt={alt}
          fill
          priority={priority}
          sizes={sizes || '(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw'}
          referrerPolicy="no-referrer"
          className={`object-cover duration-700 ease-out ${
            isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          }`}
          onLoad={() => setIsLoaded(true)}
          onError={() => setHasError(true)}
        />
      ) : (
        <Image
          src={src}
          alt={alt}
          width={width || 600}
          height={height || 800}
          priority={priority}
          referrerPolicy="no-referrer"
          className={`object-cover duration-700 ease-out ${
            isLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          }`}
          onLoad={() => setIsLoaded(true)}
          onError={() => setHasError(true)}
        />
      )}
    </div>
  );
}
