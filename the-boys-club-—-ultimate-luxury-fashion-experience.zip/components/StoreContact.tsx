'use client';

import React, { useState } from 'react';
import { Phone, MapPin, Navigation, Star, Send, CheckCircle } from 'lucide-react';
import { STORE_CONFIG } from '@/lib/config';

export function StoreContact() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !contactPhone) return;
    setFormSubmitted(true);
  };

  return (
    <section id="visit-store" className="relative w-full bg-[#070709] py-24 border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Flagship Address & Verification (6 Cols) */}
          <div className="lg:col-span-6 space-y-8">
            <div>
              <span className="text-xs uppercase tracking-[0.35em] text-[#D4AF37] font-semibold block mb-2">
                FLAGSHIP LOCATION
              </span>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
                VISIT THE BOYS CLUB
              </h2>
              <p className="text-sm sm:text-base text-neutral-400 mt-2 font-light">
                Experience our full collections in person. Inspect fabrics under showroom spotlights and enjoy custom sizing assistance.
              </p>
            </div>

            {/* Store Address & Contact Details Card */}
            <div className="p-6 sm:p-8 bg-[#0D0D11] border border-neutral-800 rounded-sm space-y-6 shadow-xl">
              <div className="space-y-2">
                <span className="font-display text-lg font-bold text-white block">
                  {STORE_CONFIG.brand.name}
                </span>
                <span className="text-xs uppercase tracking-widest text-[#D4AF37] block font-semibold">
                  {STORE_CONFIG.location.name}
                </span>
                <p className="text-sm text-neutral-300 font-light leading-relaxed">
                  {STORE_CONFIG.location.address}
                </p>
              </div>

              {/* Telephone */}
              <div className="flex items-center gap-3 pt-2 border-t border-neutral-850">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">
                    Direct Store Line
                  </span>
                  <a
                    href={`tel:${STORE_CONFIG.location.phone}`}
                    className="font-mono text-base font-bold text-white hover:text-[#D4AF37] transition-colors"
                  >
                    {STORE_CONFIG.location.phone}
                  </a>
                </div>
              </div>

              {/* Supplied Rating Display */}
              <div className="pt-4 border-t border-neutral-850 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-[#D4AF37]">
                    <span className="tracking-widest text-base">★★★★★</span>
                    <span className="font-bold text-white text-sm">5.0</span>
                  </div>
                  <span className="text-xs text-neutral-400 block mt-0.5">
                    {STORE_CONFIG.location.ratingText}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase text-neutral-500 block">
                    Demo Display
                  </span>
                </div>
              </div>

              {/* Primary Store Action Buttons */}
              <div className="pt-4 flex flex-wrap items-center gap-3">
                <a
                  href={`tel:${STORE_CONFIG.location.phone}`}
                  className="flex-1 py-3 px-5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-colors text-center shadow-lg"
                >
                  CALL STORE
                </a>

                <a
                  href={STORE_CONFIG.location.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 px-5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-white hover:text-[#D4AF37] font-semibold text-xs uppercase tracking-[0.2em] rounded-sm transition-colors text-center flex items-center justify-center gap-2"
                >
                  <Navigation className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>GET DIRECTIONS</span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Direct Store Enquiry & Booking Form (6 Cols) */}
          <div className="lg:col-span-6 bg-[#0E0E13] border border-neutral-800 rounded-sm p-6 sm:p-8 shadow-xl">
            <span className="text-xs uppercase tracking-[0.3em] text-[#D4AF37] font-semibold block mb-2">
              CUSTOMER ENQUIRY
            </span>
            <h3 className="font-display text-2xl font-bold text-white mb-2">
              CONNECT WITH OUR BOUTIQUE
            </h3>
            <p className="text-xs text-neutral-400 mb-6 font-light">
              Inquire about specific garment sizing, stock availability, or arrange an in-store private fitting session.
            </p>

            {formSubmitted ? (
              <div className="py-12 text-center space-y-3 bg-[#0A0A0D] border border-neutral-800 rounded-sm p-6">
                <CheckCircle className="w-10 h-10 text-[#D4AF37] mx-auto" />
                <h4 className="font-display text-lg font-bold text-white">
                  Enquiry Transmitted
                </h4>
                <p className="text-xs text-neutral-300 max-w-sm mx-auto">
                  Thank you, <span className="font-semibold text-white">{name}</span>. Our store manager at Gondalipokhar will respond directly to <span className="font-mono text-[#D4AF37]">{contactPhone}</span>.
                </p>
                <button
                  onClick={() => {
                    setFormSubmitted(false);
                    setName('');
                    setContactPhone('');
                    setMessage('');
                  }}
                  className="mt-4 px-4 py-2 text-[11px] uppercase tracking-wider text-neutral-400 hover:text-white underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1.5 font-medium">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Vikram Singh"
                    className="w-full bg-[#16161C] border border-neutral-700 text-white text-xs px-3.5 py-2.5 rounded-sm focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1.5 font-medium">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    placeholder="e.g. 09031752523"
                    className="w-full bg-[#16161C] border border-neutral-700 text-white text-xs px-3.5 py-2.5 rounded-sm focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-[11px] uppercase tracking-wider text-neutral-400 block mb-1.5 font-medium">
                    Enquiry Details or Fitting Request
                  </label>
                  <textarea
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Specify the piece you are interested in or desired visit date"
                    className="w-full bg-[#16161C] border border-neutral-700 text-white text-xs px-3.5 py-2.5 rounded-sm focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-all shadow-[0_0_15px_rgba(212,175,55,0.2)] flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>TRANSMIT ENQUIRY</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
