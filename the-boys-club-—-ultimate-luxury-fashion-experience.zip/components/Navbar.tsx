'use client';

import React, { useState, useEffect } from 'react';
import { Search, Heart, ShoppingBag, Menu, X, ArrowUpRight } from 'lucide-react';
import { STORE_CONFIG } from '@/lib/config';

interface NavbarProps {
  wishlistCount: number;
  bagCount: number;
  onOpenSearch: () => void;
  onOpenWishlist: () => void;
  onOpenBag: () => void;
  onReplayIntro?: () => void;
}

export function Navbar({
  wishlistCount,
  bagCount,
  onOpenSearch,
  onOpenWishlist,
  onOpenBag,
  onReplayIntro,
}: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'HOME', href: '#home' },
    { label: 'COLLECTIONS', href: '#collection' },
    { label: 'SHOWROOM', href: '#showroom' },
    { label: 'NEW ARRIVALS', href: '#new-arrivals' },
    { label: 'ABOUT', href: '#about' },
    { label: 'VISIT STORE', href: '#visit-store' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#08080A]/95 backdrop-blur-md border-b border-neutral-800/80 py-3.5 shadow-2xl'
            : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark & Monogram */}
          <a
            href="#home"
            className="flex items-center gap-3 group whitespace-nowrap shrink-0 focus:outline-none"
          >
            <div className="w-8 h-8 rounded-sm bg-[#16161B] border border-[#D4AF37]/40 flex items-center justify-center transition-all duration-300 group-hover:border-[#D4AF37] group-hover:shadow-[0_0_15px_rgba(212,175,55,0.25)]">
              <span className="font-display font-extrabold text-xs text-[#D4AF37] tracking-wider">
                {STORE_CONFIG.brand.monogram}
              </span>
            </div>
            <span className="font-display text-base md:text-lg font-bold tracking-[0.25em] text-white group-hover:text-[#F3E5AB] transition-colors">
              {STORE_CONFIG.brand.name}
            </span>
          </a>

          {/* Zone 2: 4-5 clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="relative text-xs font-semibold tracking-[0.2em] text-neutral-300 hover:text-white transition-colors duration-200 py-1 group whitespace-nowrap shrink-0"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#D4AF37] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Zone 3: Search, Wishlist, Bag & Mobile Toggle */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* Quick Search Button */}
            <button
              onClick={onOpenSearch}
              aria-label="Search clothing catalog"
              className="p-2 text-neutral-300 hover:text-[#D4AF37] transition-colors rounded-sm hover:bg-white/5"
            >
              <Search className="w-4 h-4 md:w-5 md:h-5" />
            </button>

            {/* Wishlist Button with Badge */}
            <button
              onClick={onOpenWishlist}
              aria-label={`View wishlist with ${wishlistCount} items`}
              className="relative p-2 text-neutral-300 hover:text-[#D4AF37] transition-colors rounded-sm hover:bg-white/5"
            >
              <Heart className="w-4 h-4 md:w-5 md:h-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#D4AF37] text-black font-bold text-[10px] rounded-full flex items-center justify-center tabular-nums">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Bag Button with Badge */}
            <button
              onClick={onOpenBag}
              aria-label={`View shopping bag with ${bagCount} items`}
              className="relative p-2 text-neutral-300 hover:text-[#D4AF37] transition-colors rounded-sm hover:bg-white/5"
            >
              <ShoppingBag className="w-4 h-4 md:w-5 md:h-5" />
              {bagCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#D4AF37] text-black font-bold text-[10px] rounded-full flex items-center justify-center tabular-nums">
                  {bagCount}
                </span>
              )}
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open mobile navigation menu"
              className="lg:hidden p-2 text-neutral-300 hover:text-white rounded-sm hover:bg-white/5"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Full-Screen Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-[#08080A] flex flex-col justify-between p-6 overflow-y-auto">
          {/* Top Row with Close Button */}
          <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
            <div className="flex items-center gap-2">
              <span className="font-display font-extrabold text-sm text-[#D4AF37] tracking-wider">
                {STORE_CONFIG.brand.monogram}
              </span>
              <span className="font-display text-sm font-bold tracking-[0.2em] text-white">
                {STORE_CONFIG.brand.name}
              </span>
            </div>
            <button
              onClick={() => setMobileMenuOpen(false)}
              aria-label="Close menu"
              className="p-2 text-neutral-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-col gap-6 my-auto py-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="font-display text-2xl font-bold tracking-[0.2em] text-white hover:text-[#D4AF37] transition-colors flex items-center justify-between border-b border-neutral-900 pb-3"
              >
                <span>{link.label}</span>
                <ArrowUpRight className="w-5 h-5 text-neutral-600" />
              </a>
            ))}
          </nav>

          {/* Store Location & Phone Info */}
          <div className="border-t border-neutral-800 pt-6 space-y-4">
            <div className="text-xs text-neutral-400">
              <p className="text-white font-semibold">{STORE_CONFIG.location.name}</p>
              <p className="mt-1">{STORE_CONFIG.location.address}</p>
            </div>
            <div className="flex items-center gap-3">
              <a
                href={`tel:${STORE_CONFIG.location.phone}`}
                className="flex-1 py-3 text-center text-xs uppercase tracking-widest font-bold bg-[#D4AF37] text-black rounded-sm"
              >
                Call: {STORE_CONFIG.location.phone}
              </a>
              {onReplayIntro && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onReplayIntro();
                  }}
                  className="px-4 py-3 text-xs uppercase tracking-widest text-neutral-300 border border-neutral-700 rounded-sm"
                >
                  Intro
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
