'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, ShoppingBag, Heart, ArrowRight } from 'lucide-react';
import { Product, STORE_CONFIG } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistItems: Product[];
  onRemove: (productId: string) => void;
  onMoveToBag: (product: Product) => void;
}

export function WishlistDrawer({
  isOpen,
  onClose,
  wishlistItems,
  onRemove,
  onMoveToBag,
}: WishlistDrawerProps) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Sliding Panel */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-md bg-[#0D0D11] border-l border-neutral-800 shadow-2xl flex flex-col justify-between z-10 h-full"
        >
          {/* Header */}
          <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-[#0A0A0D]">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-[#D4AF37] fill-[#D4AF37]" />
              <h2 className="font-display text-base font-bold text-white tracking-widest uppercase">
                SAVED PIECES ({wishlistItems.length})
              </h2>
            </div>
            <button
              onClick={onClose}
              aria-label="Close wishlist"
              className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Item List or Empty State */}
          <div className="flex-grow overflow-y-auto p-5 space-y-4">
            {wishlistItems.length === 0 ? (
              <div className="py-20 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center mx-auto text-neutral-500">
                  <Heart className="w-7 h-7" />
                </div>
                <h3 className="font-display text-base font-bold text-white">Your Wishlist is Empty</h3>
                <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                  Save pieces from our curated drops to keep track of your favourite streetwear and tailored garments.
                </p>
                <button
                  onClick={onClose}
                  className="mt-2 px-5 py-2.5 text-xs font-bold uppercase tracking-wider bg-[#D4AF37] text-black rounded-sm"
                >
                  DISCOVER CATALOGUE
                </button>
              </div>
            ) : (
              wishlistItems.map((item) => (
                <div
                  key={item.id}
                  className="p-3 bg-[#131318] border border-neutral-800 rounded-sm flex gap-3 group relative"
                >
                  {/* Thumbnail */}
                  <div className="relative w-20 h-24 rounded overflow-hidden shrink-0 bg-neutral-900">
                    <FashionImage src={item.image} alt={item.name} fill />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-neutral-400 block">
                        {item.category.replace('-', ' ')}
                      </span>
                      <h4 className="font-display text-xs font-bold text-white truncate">
                        {item.name}
                      </h4>
                      <span className="font-mono text-xs font-bold text-[#D4AF37] tabular-nums mt-1 block">
                        {STORE_CONFIG.currency.format(item.price)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <button
                        onClick={() => {
                          onMoveToBag(item);
                          onRemove(item.id);
                        }}
                        className="px-3 py-1.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black text-[10px] font-bold uppercase tracking-wider rounded-sm transition-colors flex items-center gap-1.5"
                      >
                        <ShoppingBag className="w-3 h-3" />
                        <span>Move to Bag</span>
                      </button>

                      <button
                        onClick={() => onRemove(item.id)}
                        className="p-1.5 text-neutral-400 hover:text-red-400 transition-colors"
                        title="Remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer note */}
          <div className="p-4 border-t border-neutral-800 bg-[#0A0A0D] text-center text-[11px] text-neutral-400">
            Items saved are stored in your current browser session.
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
