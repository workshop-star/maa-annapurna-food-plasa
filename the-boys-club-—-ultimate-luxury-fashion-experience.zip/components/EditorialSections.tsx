'use client';

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Sparkles, MapPin, ShieldCheck, Compass, CheckCircle } from 'lucide-react';
import { STORE_CONFIG, PRODUCTS, Product } from '@/lib/config';
import { FashionImage } from '@/components/FashionImage';

interface EditorialSectionsProps {
  onExploreCollection: (category?: string) => void;
  onQuickView: (product: Product) => void;
  onOpenShowroom: () => void;
}

export function EditorialSections({
  onExploreCollection,
  onQuickView,
  onOpenShowroom,
}: EditorialSectionsProps) {
  // Everyday Icons curated subset
  const everydayIcons = PRODUCTS.filter((p) => p.isEverydayIcon).slice(0, 4);

  return (
    <div className="w-full bg-[#08080A] space-y-28 md:space-y-36 py-12">
      {/* SECTION A: NEW SEASON, NEW ENERGY */}
      <section id="new-season" className="relative w-full overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-sm overflow-hidden border border-neutral-800 bg-[#0C0C10] min-h-[520px] md:min-h-[620px] flex items-center shadow-2xl">
            {/* Background Campaign Photography */}
            <div className="absolute inset-0 z-0">
              <FashionImage
                src="https://images.unsplash.com/photo-1516257984-b1b4d707412e?q=80&w=1600&auto=format&fit=crop"
                alt="New Season New Energy Campaign"
                fill
                className="scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#08080A]/95 via-[#08080A]/75 to-transparent" />
              <div className="absolute inset-0 bg-radial from-transparent via-[#08080A]/50 to-[#08080A]" />
            </div>

            {/* Content Foreground */}
            <div className="relative z-10 max-w-2xl p-8 sm:p-12 lg:p-16 space-y-6">
              <span className="text-xs uppercase tracking-[0.35em] text-[#D4AF37] font-semibold block">
                EDITORIAL CAPSULE // 2026
              </span>
              <h2 className="font-display text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.08] text-balance">
                NEW SEASON. <br />
                <span className="gold-gradient-text">NEW ENERGY.</span>
              </h2>
              <p className="text-sm sm:text-base text-neutral-300 font-light leading-relaxed">
                Step into the high-performance silhouettes of the new era. Drop-shoulder structures, bonded thermal layers, and curated textures engineered to hold their shape through relentless days.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => onExploreCollection('new-arrivals')}
                  className="px-8 py-3.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-all duration-300 flex items-center gap-3 shadow-[0_0_20px_rgba(212,175,55,0.25)] group"
                >
                  <span>EXPLORE COLLECTION</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION B: BUILT FOR THE STREETS */}
      <section id="streetwear-spotlight" className="relative w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Visual Column Left (6 Cols) */}
            <div className="lg:col-span-6 relative order-2 lg:order-1">
              <div className="relative aspect-[4/5] rounded-sm overflow-hidden border border-[#27272A] shadow-2xl group">
                <FashionImage
                  src="https://images.unsplash.com/photo-1509967419530-da38b4704bc6?q=80&w=1200&auto=format&fit=crop"
                  alt="Built for the Streets Streetwear Campaign"
                  fill
                  className="group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />
                <div className="absolute bottom-6 left-6 right-6">
                  <span className="text-[10px] uppercase tracking-[0.3em] text-[#D4AF37] block font-semibold">
                    STREETWEAR SPECIFICATION
                  </span>
                  <p className="font-display text-lg font-bold text-white mt-1">
                    Heavy French Terry & Selvedge Construction
                  </p>
                </div>
              </div>
            </div>

            {/* Text Editorial Right (6 Cols) */}
            <div className="lg:col-span-6 space-y-6 order-1 lg:order-2">
              <span className="text-xs uppercase tracking-[0.35em] text-[#D4AF37] font-semibold block">
                UNDERGROUND REFINEMENT
              </span>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                BUILT FOR THE STREETS. <br />
                DESIGNED TO DOMINATE.
              </h2>
              <p className="text-sm sm:text-base text-neutral-300 font-light leading-relaxed">
                We believe true streetwear isn&apos;t just printed graphics—it is weight, silhouette, and posture. Every hoodie uses dense 450 GSM diagonal fleece. Every denim pair is woven on heritage shuttle looms with red-line selvedge margins.
              </p>

              {/* Three Editorial Quality Pillars */}
              <div className="space-y-4 pt-2">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-sm bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0 text-[#D4AF37] font-mono text-xs font-bold">
                    01
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">280+ GSM Heavy Cotton</h4>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Structured fabric drape that never clings or loses its boxy architectural form.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-sm bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0 text-[#D4AF37] font-mono text-xs font-bold">
                    02
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Custom Cast Alloy Hardware</h4>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Subtle champagne brass zippers and laser-engraved TBC buttons.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-sm bg-neutral-900 border border-neutral-800 flex items-center justify-center shrink-0 text-[#D4AF37] font-mono text-xs font-bold">
                    03
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Tailored Comfort Geometry</h4>
                    <p className="text-xs text-neutral-400 mt-0.5">
                      Engineered for Indian climate versatility with breathable organic yarn blends.
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={() => onExploreCollection('streetwear')}
                  className="px-6 py-3.5 bg-white hover:bg-[#D4AF37] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-colors"
                >
                  VIEW STREETWEAR EDIT
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION C: THE EVERYDAY ICONS */}
      <section id="everyday-icons" className="relative w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <span className="text-xs uppercase tracking-[0.35em] text-[#D4AF37] font-semibold block mb-2">
                FOUNDATIONAL WARDROBE
              </span>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
                THE EVERYDAY ICONS
              </h2>
              <p className="text-sm sm:text-base text-neutral-400 mt-2 max-w-xl font-light">
                The core pieces you reach for every morning. Unfussy, perfectly proportioned, and impeccably constructed.
              </p>
            </div>
            <button
              onClick={() => onExploreCollection('all')}
              className="text-xs uppercase tracking-[0.2em] text-[#D4AF37] hover:underline font-semibold flex items-center gap-2 self-start"
            >
              <span>See All Icons</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Clean 4-Column Product Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {everydayIcons.map((item) => (
              <div
                key={item.id}
                onClick={() => onQuickView(item)}
                className="group bg-[#0D0D11] border border-neutral-850 hover:border-neutral-700 rounded-sm overflow-hidden cursor-pointer transition-all duration-300 flex flex-col justify-between"
              >
                <div className="relative aspect-[3/4] w-full overflow-hidden bg-neutral-900">
                  <FashionImage
                    src={item.image}
                    alt={item.name}
                    fill
                    className="group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute top-2.5 left-2.5 px-2 py-0.5 bg-black/80 text-[9px] uppercase tracking-wider text-[#D4AF37] font-bold">
                    Essential
                  </div>
                </div>

                <div className="p-4">
                  <span className="text-[10px] uppercase tracking-wider text-neutral-400 block mb-1">
                    {item.category.replace('-', ' ')}
                  </span>
                  <h3 className="font-display text-sm font-bold text-white group-hover:text-[#D4AF37] transition-colors line-clamp-1">
                    {item.name}
                  </h3>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="font-mono text-sm font-semibold text-white tabular-nums">
                      {STORE_CONFIG.currency.format(item.price)}
                    </span>
                    <span className="text-[11px] text-[#D4AF37] font-medium group-hover:underline">
                      View Piece →
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION D: YOUR STYLE. YOUR RULES. (Split-screen Editorial) */}
      <section className="relative w-full border-t border-b border-neutral-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
            {/* Split Left: Tailored Luxury Statement */}
            <div className="relative rounded-sm overflow-hidden border border-neutral-800 bg-[#0C0C10] p-8 md:p-12 flex flex-col justify-between min-h-[420px] group">
              <div className="absolute inset-0 z-0">
                <FashionImage
                  src="https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1200&auto=format&fit=crop"
                  alt="Tailored Modern Look"
                  fill
                  className="group-hover:scale-105 transition-transform duration-700 opacity-40"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0C0C10] via-[#0C0C10]/80 to-transparent" />
              </div>

              <div className="relative z-10">
                <span className="text-[10px] uppercase tracking-[0.3em] text-[#D4AF37] font-semibold block mb-2">
                  MODERN REFINEMENT
                </span>
                <h3 className="font-display text-2xl sm:text-3xl font-black text-white">
                  ARCHITECTURAL SHIRTING
                </h3>
              </div>

              <div className="relative z-10 pt-8">
                <p className="text-xs sm:text-sm text-neutral-300 font-light mb-4 max-w-sm">
                  Fluid Tencel and Italian cotton poplin cut with Cuban camp collars for effortless high-summer presence.
                </p>
                <button
                  onClick={() => onExploreCollection('premium-shirts')}
                  className="text-xs uppercase tracking-[0.2em] font-bold text-white hover:text-[#D4AF37] flex items-center gap-2"
                >
                  <span>Explore Shirts</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Split Right: Selvedge & Denim Attitude */}
            <div className="relative rounded-sm overflow-hidden border border-neutral-800 bg-[#0C0C10] p-8 md:p-12 flex flex-col justify-between min-h-[420px] group">
              <div className="absolute inset-0 z-0">
                <FashionImage
                  src="https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=1200&auto=format&fit=crop"
                  alt="Raw Selvedge Denim"
                  fill
                  className="group-hover:scale-105 transition-transform duration-700 opacity-40"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0C0C10] via-[#0C0C10]/80 to-transparent" />
              </div>

              <div className="relative z-10">
                <span className="text-[10px] uppercase tracking-[0.3em] text-[#D4AF37] font-semibold block mb-2">
                  RAW JAPANESE DENIM
                </span>
                <h3 className="font-display text-2xl sm:text-3xl font-black text-white">
                  SELVEDGE ATTITUDE
                </h3>
              </div>

              <div className="relative z-10 pt-8">
                <p className="text-xs sm:text-sm text-neutral-300 font-light mb-4 max-w-sm">
                  13.5 oz virgin cotton woven slowly on shuttle looms. Form-fitting fades that map exclusively to your lifestyle.
                </p>
                <button
                  onClick={() => onExploreCollection('jeans-denim')}
                  className="text-xs uppercase tracking-[0.2em] font-bold text-white hover:text-[#D4AF37] flex items-center gap-2"
                >
                  <span>Explore Denim</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION E: THE TBC EXPERIENCE */}
      <section className="relative w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-sm overflow-hidden border border-[#D4AF37]/30 bg-gradient-to-br from-[#121217] via-[#0E0E12] to-[#08080A] p-8 sm:p-12 lg:p-16 text-center shadow-2xl">
            <div className="max-w-2xl mx-auto space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-black/60 border border-[#D4AF37]/40 rounded-full text-[11px] uppercase tracking-[0.25em] text-[#D4AF37]">
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>IN-STORE CONSULTATION</span>
              </div>

              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
                THE TBC EXPERIENCE
              </h2>

              <p className="text-sm sm:text-base text-neutral-300 font-light leading-relaxed">
                Step into our Gondalipokhar boutique for personal garment fitting, selvedge hem customisation, and exclusive limited edition drop access unavailable anywhere else.
              </p>

              <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
                <a
                  href="#visit-store"
                  className="px-6 py-3.5 bg-[#D4AF37] hover:bg-[#F3E5AB] text-black font-bold text-xs uppercase tracking-[0.2em] rounded-sm transition-colors shadow-lg"
                >
                  VISIT THE BOUTIQUE
                </a>

                <button
                  onClick={onOpenShowroom}
                  className="px-6 py-3.5 bg-black/60 hover:bg-black text-white hover:text-[#D4AF37] border border-neutral-700 text-xs font-semibold uppercase tracking-[0.2em] rounded-sm transition-colors"
                >
                  LAUNCH 3D VIRTUAL TOUR
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
