// Central Client Demo Configuration for THE BOYS CLUB
// Easily customizable for other fashion clients

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  sizes: string[];
  colors: { name: string; hex: string }[];
  image: string;
  secondaryImage: string;
  tag?: string;
  stockStatus: 'in_stock' | 'low_stock' | 'preorder';
  description: string;
  details: string[];
  isNewArrival?: boolean;
  isStreetwear?: boolean;
  isEverydayIcon?: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
}

export const STORE_CONFIG = {
  brand: {
    name: 'THE BOYS CLUB',
    shortName: 'TBC',
    tagline: 'OWN YOUR STYLE. RULE YOUR WORLD.',
    monogram: 'TBC',
    subheading: 'Discover the next level of everyday fashion at THE BOYS CLUB.',
    heroHeadlinePart1: 'NOT JUST STYLE.',
    heroHeadlinePart2: "IT'S AN ATTITUDE.",
    aboutHeadline: "MORE THAN A LOOK. IT'S A LIFESTYLE.",
    aboutCopy:
      'Born at the crossroads of raw street culture and architectural minimalism, THE BOYS CLUB curates luxury garments engineered for modern men who make their own rules. From heavyweight drop-shoulder essentials to sharp tailored overshirts, every piece embodies quiet power and effortless distinction.',
  },
  location: {
    name: 'GONDALIPOKHAR FLAGSHIP',
    address: 'Angara, Cheldagsoso, Jharkhand – 835103',
    phone: '09031752523',
    phoneFormatted: '+91 90317 52523',
    googleMapsUrl:
      'https://www.google.com/maps/search/?api=1&query=Angara+Cheldagsoso+Jharkhand+835103',
    rating: 5,
    ratingText: '15 people · 5-star display',
    ratingNote: 'Supplied demo rating · Demonstration content',
  },
  currency: {
    symbol: '₹',
    code: 'INR',
    format: (amount: number) =>
      `₹${amount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`,
  },
  colors: {
    brandBlack: '#0A0A0C',
    charcoal: '#141418',
    ivory: '#F4F4EE',
    champagneGold: '#D4AF37',
    goldMuted: '#9B8030',
    borderMuted: 'rgba(212, 175, 55, 0.15)',
  },
  seo: {
    title: 'THE BOYS CLUB — Luxury Streetwear & Menswear Boutique | Gondalipokhar',
    description:
      'Experience the pinnacle of luxury streetwear, oversized t-shirts, tailored jackets, premium denim, and contemporary casuals at THE BOYS CLUB, Angara, Jharkhand.',
  },
  categories: [
    { id: 'all', name: 'All Collections', slug: 'all', description: 'Complete catalogue' },
    { id: 'oversized-tees', name: 'Oversized T-Shirts', slug: 'oversized-tees', description: '280 GSM heavy drop-shoulder silhouettes' },
    { id: 'premium-shirts', name: 'Premium Shirts', slug: 'premium-shirts', description: 'Architectural poplin, cuban collars & overshirts' },
    { id: 'jeans-denim', name: 'Jeans & Denim', slug: 'jeans-denim', description: 'Raw Japanese selvedge & relaxed street washes' },
    { id: 'jackets', name: 'Jackets', slug: 'jackets', description: 'Tactical bombers, chore jackets & structured blousons' },
    { id: 'trousers', name: 'Trousers', slug: 'trousers', description: 'Pleated wide-leg & modern utility pants' },
    { id: 'casual-wear', name: 'Casual Wear', slug: 'casual-wear', description: 'Daily elevated lounge sets & textured knits' },
    { id: 'streetwear', name: 'Streetwear', slug: 'streetwear', description: 'Graphic statements & midnight monochrome fits' },
    { id: 'traditional-wear', name: 'Traditional Wear', slug: 'traditional-wear', description: 'Bespoke modern kurtas & celebratory Nehru sets' },
    { id: 'new-arrivals', name: 'New Arrivals', slug: 'new-arrivals', description: 'Fresh drops from the latest Gondalipokhar runway' },
  ] as Category[],
};

// Rich curated catalog with verified high-contrast fashion photography and built-in SVG luxury fallbacks
export const PRODUCTS: Product[] = [
  {
    id: 'tbc-tee-01',
    name: 'Aethel Heavyweight Drop-Shoulder Tee',
    category: 'oversized-tees',
    price: 1899,
    originalPrice: 2499,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Onyx Black', hex: '#111111' },
      { name: 'Champagne Ivory', hex: '#F3EFE0' },
      { name: 'Washed Charcoal', hex: '#333338' },
    ],
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=1000&auto=format&fit=crop',
    tag: 'Bestseller',
    stockStatus: 'in_stock',
    description:
      'Constructed from 280 GSM combed organic cotton with a tailored ribbed collar and dropped shoulder seams. Finished with micro-embroidered TBC coordinates.',
    details: ['100% 280 GSM French Terry Cotton', 'Preshrunk fabric with silicone wash', 'Reinforced neck tape', 'Made in India'],
    isNewArrival: false,
    isStreetwear: true,
    isEverydayIcon: true,
  },
  {
    id: 'tbc-shirt-01',
    name: 'Monolith Architectural Cuban Shirt',
    category: 'premium-shirts',
    price: 2799,
    originalPrice: 3499,
    sizes: ['M', 'L', 'XL'],
    colors: [
      { name: 'Smoked Ivory', hex: '#EBE7DF' },
      { name: 'Midnight Navy', hex: '#131B2A' },
      { name: 'Olive Drab', hex: '#3F4236' },
    ],
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=1000&auto=format&fit=crop',
    tag: 'Runway',
    stockStatus: 'low_stock',
    description:
      'Boxy vacation silhouette engineered with high-density cotton-tencel blend for a fluid drape. Hidden mother-of-pearl hardware and structured lapels.',
    details: ['60% Tencel, 40% Fine Combed Cotton', 'Relaxed boxy cut', 'Camp collar with top loop', 'Dry clean or cold hand wash'],
    isNewArrival: true,
    isStreetwear: false,
    isEverydayIcon: true,
  },
  {
    id: 'tbc-jacket-01',
    name: 'Sector-07 Tactical Cropped Bomber',
    category: 'jackets',
    price: 4999,
    originalPrice: 6299,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Pitch Matte Black', hex: '#0B0B0D' },
      { name: 'Gunmetal Silver', hex: '#5A5B60' },
    ],
    image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1544441893-675973e31985?q=80&w=1000&auto=format&fit=crop',
    tag: 'Limited 50 Pcs',
    stockStatus: 'low_stock',
    description:
      'Architectural cropped silhouette with dual-way champagne brass zippers, ergonomic storm flap, and diamond quilted satin thermal lining.',
    details: ['Water-repellent technical nylon shell', 'Custom engraved TBC pulls', 'Ribbed wool-blend cuffs and hem', 'Internal chest passport pocket'],
    isNewArrival: true,
    isStreetwear: true,
    isEverydayIcon: false,
  },
  {
    id: 'tbc-denim-01',
    name: 'Kuro Raw Selvedge Relaxed Denim',
    category: 'jeans-denim',
    price: 3899,
    originalPrice: 4899,
    sizes: ['30', '32', '34', '36'],
    colors: [
      { name: 'Deep Indigo Selvedge', hex: '#1B263B' },
      { name: 'Faded Ash Black', hex: '#2B2B2F' },
    ],
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1582552938357-32b906df40cb?q=80&w=1000&auto=format&fit=crop',
    tag: 'Selvedge ID',
    stockStatus: 'in_stock',
    description:
      'Woven on shuttle looms using 13.5 oz virgin cotton yarn. Cut with a medium-high rise, relaxed straight leg, and custom cast alloy rivets.',
    details: ['13.5 oz Red-line Selvedge Denim', 'Button fly closure', 'Genuine leather back patch', 'Will develop bespoke fades with wear'],
    isNewArrival: false,
    isStreetwear: true,
    isEverydayIcon: true,
  },
  {
    id: 'tbc-trouser-01',
    name: 'Atelier Double-Pleat Wide Trousers',
    category: 'trousers',
    price: 3299,
    originalPrice: 3999,
    sizes: ['30', '32', '34', '36'],
    colors: [
      { name: 'Warm Charcoal', hex: '#262629' },
      { name: 'Oatmeal Taupe', hex: '#B5A99B' },
      { name: 'Pure Noir', hex: '#0D0D0E' },
    ],
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?q=80&w=1000&auto=format&fit=crop',
    tag: 'Tailored',
    stockStatus: 'in_stock',
    description:
      'Inspired by classic Savile Row tailoring adapted for modern streetwear. Deep front double pleats, interior grip waistband, and a fluid wide break.',
    details: ['Wool-viscose blend with stretch', 'Side adjuster tabs (beltless design)', 'Unhemmed 34" inseam for custom tailoring', 'Dry clean recommended'],
    isNewArrival: true,
    isStreetwear: false,
    isEverydayIcon: true,
  },
  {
    id: 'tbc-traditional-01',
    name: 'Gondali Asymmetric Festive Kurta',
    category: 'traditional-wear',
    price: 3999,
    originalPrice: 4999,
    sizes: ['38', '40', '42', '44'],
    colors: [
      { name: 'Midnight Silk Black', hex: '#0A0A0C' },
      { name: 'Champagne Ochre', hex: '#C59E47' },
      { name: 'Imperial Maroon', hex: '#4A0E17' },
    ],
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1000&auto=format&fit=crop',
    tag: 'Handcrafted',
    stockStatus: 'in_stock',
    description:
      'Contemporary celebration wear designed for the discerning gentleman. Diagonal overlapping placket with handcrafted metallic metal clasps and tailored side vents.',
    details: ['Pure Matka Silk & Chanderi Weave', 'Mandarin standing collar', 'Asymmetrical hidden button placket', 'Dry clean only'],
    isNewArrival: false,
    isStreetwear: false,
    isEverydayIcon: false,
  },
  {
    id: 'tbc-casual-01',
    name: 'Waffle Knit Minimalist Overshirt',
    category: 'casual-wear',
    price: 2699,
    originalPrice: 3299,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Bone White', hex: '#EAE6DD' },
      { name: 'Earth Stone', hex: '#877E71' },
      { name: 'Deep Espresso', hex: '#2A201A' },
    ],
    image: 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=1000&auto=format&fit=crop',
    tag: 'Layering Essential',
    stockStatus: 'in_stock',
    description:
      'Heavy 340 GSM micro-waffle texture that transitions seamlessly from indoor air conditioning to evening street strolls. Premium matte horn buttons.',
    details: ['100% Breathable waffle knit cotton', 'Dual chest utility pockets', 'Reinforced elbow patches', 'Regular-oversized fit'],
    isNewArrival: false,
    isStreetwear: false,
    isEverydayIcon: true,
  },
  {
    id: 'tbc-streetwear-02',
    name: 'Hyper-Graphic Acid Wash Hoodie',
    category: 'streetwear',
    price: 3499,
    originalPrice: 4299,
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Vintage Acid Charcoal', hex: '#2E2E33' },
      { name: 'Distressed Forest', hex: '#233227' },
    ],
    image: 'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?q=80&w=1000&auto=format&fit=crop',
    tag: 'Limited Edition',
    stockStatus: 'low_stock',
    description:
      '450 GSM diagonal loopback fleece subjected to artisanal mineral wash. Features oversized double-layered hood without drawstrings for clean high-fashion drape.',
    details: ['450 GSM Heavy French Terry', 'Double-lined crossover hood', 'Hidden kangaroo side zips', 'Hand-applied mineral wash finish'],
    isNewArrival: true,
    isStreetwear: true,
    isEverydayIcon: false,
  },
  {
    id: 'tbc-shirt-02',
    name: 'Imperial Linen Mandarin Collar Shirt',
    category: 'premium-shirts',
    price: 2499,
    originalPrice: 3199,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Crisp Cloud White', hex: '#FAFAFA' },
      { name: 'Dusty Sage', hex: '#8A9A86' },
      { name: 'Desert Sand', hex: '#D2C1A8' },
    ],
    image: 'https://images.unsplash.com/photo-1603252109303-2751441dd157?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1589310243389-96a5483213a8?q=80&w=1000&auto=format&fit=crop',
    tag: 'Summer Pure',
    stockStatus: 'in_stock',
    description:
      'Woven from 100% Normandy flax linen. Exceptionally airy and breathable for Indian summers with an elevated stand collar and rounded barrel cuffs.',
    details: ['100% European Flax Linen', 'Garment washed for ultra softness', 'Mother of pearl buttons', 'Tailored slim-relaxed fit'],
    isNewArrival: false,
    isStreetwear: false,
    isEverydayIcon: true,
  },
  {
    id: 'tbc-jacket-02',
    name: 'Vanguard Raw Selvedge Trucker Jacket',
    category: 'jackets',
    price: 4599,
    originalPrice: 5699,
    sizes: ['M', 'L', 'XL'],
    colors: [
      { name: 'Unwashed Midnight Raw', hex: '#161E2E' },
      { name: 'Black Sulfur Overdye', hex: '#1C1C1E' },
    ],
    image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?q=80&w=1000&auto=format&fit=crop',
    secondaryImage: 'https://images.unsplash.com/photo-1516257984-b1b4d707412e?q=80&w=1000&auto=format&fit=crop',
    tag: 'Iconic',
    stockStatus: 'in_stock',
    description:
      'The definitive denim jacket reinvented with dropped shoulders and streamlined welt pockets. Features custom antique gold shank buttons and internal selvedge line accents.',
    details: ['14 oz Kurabo Japanese Selvedge', 'Antiqued brass hardware', 'Adjustable waist tabs', 'Triple-needle felled chain-stitching'],
    isNewArrival: false,
    isStreetwear: true,
    isEverydayIcon: true,
  },
];
